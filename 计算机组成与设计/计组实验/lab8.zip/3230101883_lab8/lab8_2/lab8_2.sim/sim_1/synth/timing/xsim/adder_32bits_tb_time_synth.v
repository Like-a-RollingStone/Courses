// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
// Date        : Tue Sep 30 20:25:24 2025
// Host        : DESKTOP-3MS8VAT running 64-bit major release  (build 9200)
// Command     : write_verilog -mode timesim -nolib -sdf_anno true -force -file
//               C:/Users/PC/Desktop/VivadoProjects/lab8_2/lab8_2.sim/sim_1/synth/timing/xsim/adder_32bits_tb_time_synth.v
// Design      : adder_32bits
// Purpose     : This verilog netlist is a timing simulation representation of the design and should not be modified or
//               synthesized. Please ensure that this netlist is used with the corresponding SDF file.
// Device      : xc7a200tfbg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps
`define XIL_TIMING

(* NotValidForBitStream *)
module adder_32bits
   (a,
    b,
    ci,
    s,
    co);
  input [31:0]a;
  input [31:0]b;
  input ci;
  output [31:0]s;
  output co;

  wire [31:0]a;
  wire [31:0]a_IBUF;
  wire [31:0]b;
  wire [31:0]b_IBUF;
  wire ci;
  wire ci_IBUF;
  wire co;
  wire co_OBUF;
  wire co_OBUF_inst_i_2_n_3;
  wire [31:0]s;
  wire [31:0]s_OBUF;
  wire \s_OBUF[12]_inst_i_2_n_0 ;
  wire \s_OBUF[12]_inst_i_2_n_1 ;
  wire \s_OBUF[12]_inst_i_2_n_2 ;
  wire \s_OBUF[12]_inst_i_2_n_3 ;
  wire \s_OBUF[12]_inst_i_3_n_0 ;
  wire \s_OBUF[12]_inst_i_4_n_0 ;
  wire \s_OBUF[12]_inst_i_5_n_0 ;
  wire \s_OBUF[12]_inst_i_6_n_0 ;
  wire \s_OBUF[13]_inst_i_2_n_0 ;
  wire \s_OBUF[15]_inst_i_2_n_0 ;
  wire \s_OBUF[15]_inst_i_3_n_1 ;
  wire \s_OBUF[15]_inst_i_3_n_2 ;
  wire \s_OBUF[15]_inst_i_3_n_3 ;
  wire \s_OBUF[15]_inst_i_4_n_0 ;
  wire \s_OBUF[15]_inst_i_6_n_0 ;
  wire \s_OBUF[15]_inst_i_7_n_0 ;
  wire \s_OBUF[15]_inst_i_8_n_0 ;
  wire \s_OBUF[15]_inst_i_9_n_0 ;
  wire \s_OBUF[20]_inst_i_2_n_0 ;
  wire \s_OBUF[20]_inst_i_2_n_1 ;
  wire \s_OBUF[20]_inst_i_2_n_2 ;
  wire \s_OBUF[20]_inst_i_2_n_3 ;
  wire \s_OBUF[20]_inst_i_3_n_0 ;
  wire \s_OBUF[20]_inst_i_4_n_0 ;
  wire \s_OBUF[20]_inst_i_5_n_0 ;
  wire \s_OBUF[20]_inst_i_6_n_0 ;
  wire \s_OBUF[21]_inst_i_2_n_0 ;
  wire \s_OBUF[23]_inst_i_2_n_0 ;
  wire \s_OBUF[23]_inst_i_3_n_1 ;
  wire \s_OBUF[23]_inst_i_3_n_2 ;
  wire \s_OBUF[23]_inst_i_3_n_3 ;
  wire \s_OBUF[23]_inst_i_4_n_0 ;
  wire \s_OBUF[23]_inst_i_5_n_0 ;
  wire \s_OBUF[23]_inst_i_6_n_0 ;
  wire \s_OBUF[23]_inst_i_7_n_0 ;
  wire \s_OBUF[23]_inst_i_8_n_0 ;
  wire \s_OBUF[28]_inst_i_2_n_0 ;
  wire \s_OBUF[28]_inst_i_2_n_1 ;
  wire \s_OBUF[28]_inst_i_2_n_2 ;
  wire \s_OBUF[28]_inst_i_2_n_3 ;
  wire \s_OBUF[28]_inst_i_2_n_4 ;
  wire \s_OBUF[28]_inst_i_2_n_5 ;
  wire \s_OBUF[28]_inst_i_2_n_6 ;
  wire \s_OBUF[28]_inst_i_2_n_7 ;
  wire \s_OBUF[28]_inst_i_3_n_0 ;
  wire \s_OBUF[28]_inst_i_4_n_0 ;
  wire \s_OBUF[28]_inst_i_5_n_0 ;
  wire \s_OBUF[28]_inst_i_6_n_0 ;
  wire \s_OBUF[29]_inst_i_2_n_0 ;
  wire \s_OBUF[31]_inst_i_10_n_0 ;
  wire \s_OBUF[31]_inst_i_11_n_0 ;
  wire \s_OBUF[31]_inst_i_12_n_0 ;
  wire \s_OBUF[31]_inst_i_2_n_0 ;
  wire \s_OBUF[31]_inst_i_3_n_0 ;
  wire \s_OBUF[31]_inst_i_3_n_1 ;
  wire \s_OBUF[31]_inst_i_3_n_2 ;
  wire \s_OBUF[31]_inst_i_3_n_3 ;
  wire \s_OBUF[31]_inst_i_3_n_4 ;
  wire \s_OBUF[31]_inst_i_3_n_5 ;
  wire \s_OBUF[31]_inst_i_3_n_6 ;
  wire \s_OBUF[31]_inst_i_3_n_7 ;
  wire \s_OBUF[31]_inst_i_4_n_0 ;
  wire \s_OBUF[31]_inst_i_5_n_7 ;
  wire \s_OBUF[31]_inst_i_6_n_7 ;
  wire \s_OBUF[31]_inst_i_7_n_0 ;
  wire \s_OBUF[31]_inst_i_8_n_0 ;
  wire \s_OBUF[31]_inst_i_9_n_0 ;
  wire \s_OBUF[4]_inst_i_2_n_0 ;
  wire \s_OBUF[4]_inst_i_2_n_1 ;
  wire \s_OBUF[4]_inst_i_2_n_2 ;
  wire \s_OBUF[4]_inst_i_2_n_3 ;
  wire \s_OBUF[4]_inst_i_3_n_0 ;
  wire \s_OBUF[4]_inst_i_4_n_0 ;
  wire \s_OBUF[4]_inst_i_5_n_0 ;
  wire \s_OBUF[4]_inst_i_6_n_0 ;
  wire \s_OBUF[7]_inst_i_2_n_0 ;
  wire \s_OBUF[7]_inst_i_2_n_1 ;
  wire \s_OBUF[7]_inst_i_2_n_2 ;
  wire \s_OBUF[7]_inst_i_2_n_3 ;
  wire \s_OBUF[7]_inst_i_3_n_0 ;
  wire \s_OBUF[7]_inst_i_4_n_0 ;
  wire \s_OBUF[7]_inst_i_5_n_0 ;
  wire \s_OBUF[7]_inst_i_6_n_0 ;
  wire \s_OBUF[7]_inst_i_7_n_0 ;
  wire [8:0]sum0_0;
  wire [8:0]sum1_0;
  wire [8:0]sum2_0;
  wire [3:1]NLW_co_OBUF_inst_i_2_CO_UNCONNECTED;
  wire [3:0]NLW_co_OBUF_inst_i_2_O_UNCONNECTED;
  wire [3:1]\NLW_s_OBUF[15]_inst_i_5_CO_UNCONNECTED ;
  wire [3:0]\NLW_s_OBUF[15]_inst_i_5_O_UNCONNECTED ;
  wire [3:0]\NLW_s_OBUF[31]_inst_i_5_CO_UNCONNECTED ;
  wire [3:1]\NLW_s_OBUF[31]_inst_i_5_O_UNCONNECTED ;
  wire [3:0]\NLW_s_OBUF[31]_inst_i_6_CO_UNCONNECTED ;
  wire [3:1]\NLW_s_OBUF[31]_inst_i_6_O_UNCONNECTED ;

initial begin
 $sdf_annotate("adder_32bits_tb_time_synth.sdf",,,,"tool_control");
end
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[0]_inst 
       (.I(a[0]),
        .O(a_IBUF[0]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[10]_inst 
       (.I(a[10]),
        .O(a_IBUF[10]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[11]_inst 
       (.I(a[11]),
        .O(a_IBUF[11]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[12]_inst 
       (.I(a[12]),
        .O(a_IBUF[12]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[13]_inst 
       (.I(a[13]),
        .O(a_IBUF[13]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[14]_inst 
       (.I(a[14]),
        .O(a_IBUF[14]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[15]_inst 
       (.I(a[15]),
        .O(a_IBUF[15]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[16]_inst 
       (.I(a[16]),
        .O(a_IBUF[16]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[17]_inst 
       (.I(a[17]),
        .O(a_IBUF[17]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[18]_inst 
       (.I(a[18]),
        .O(a_IBUF[18]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[19]_inst 
       (.I(a[19]),
        .O(a_IBUF[19]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[1]_inst 
       (.I(a[1]),
        .O(a_IBUF[1]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[20]_inst 
       (.I(a[20]),
        .O(a_IBUF[20]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[21]_inst 
       (.I(a[21]),
        .O(a_IBUF[21]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[22]_inst 
       (.I(a[22]),
        .O(a_IBUF[22]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[23]_inst 
       (.I(a[23]),
        .O(a_IBUF[23]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[24]_inst 
       (.I(a[24]),
        .O(a_IBUF[24]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[25]_inst 
       (.I(a[25]),
        .O(a_IBUF[25]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[26]_inst 
       (.I(a[26]),
        .O(a_IBUF[26]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[27]_inst 
       (.I(a[27]),
        .O(a_IBUF[27]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[28]_inst 
       (.I(a[28]),
        .O(a_IBUF[28]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[29]_inst 
       (.I(a[29]),
        .O(a_IBUF[29]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[2]_inst 
       (.I(a[2]),
        .O(a_IBUF[2]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[30]_inst 
       (.I(a[30]),
        .O(a_IBUF[30]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[31]_inst 
       (.I(a[31]),
        .O(a_IBUF[31]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[3]_inst 
       (.I(a[3]),
        .O(a_IBUF[3]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[4]_inst 
       (.I(a[4]),
        .O(a_IBUF[4]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[5]_inst 
       (.I(a[5]),
        .O(a_IBUF[5]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[6]_inst 
       (.I(a[6]),
        .O(a_IBUF[6]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[7]_inst 
       (.I(a[7]),
        .O(a_IBUF[7]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[8]_inst 
       (.I(a[8]),
        .O(a_IBUF[8]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[9]_inst 
       (.I(a[9]),
        .O(a_IBUF[9]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[0]_inst 
       (.I(b[0]),
        .O(b_IBUF[0]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[10]_inst 
       (.I(b[10]),
        .O(b_IBUF[10]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[11]_inst 
       (.I(b[11]),
        .O(b_IBUF[11]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[12]_inst 
       (.I(b[12]),
        .O(b_IBUF[12]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[13]_inst 
       (.I(b[13]),
        .O(b_IBUF[13]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[14]_inst 
       (.I(b[14]),
        .O(b_IBUF[14]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[15]_inst 
       (.I(b[15]),
        .O(b_IBUF[15]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[16]_inst 
       (.I(b[16]),
        .O(b_IBUF[16]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[17]_inst 
       (.I(b[17]),
        .O(b_IBUF[17]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[18]_inst 
       (.I(b[18]),
        .O(b_IBUF[18]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[19]_inst 
       (.I(b[19]),
        .O(b_IBUF[19]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[1]_inst 
       (.I(b[1]),
        .O(b_IBUF[1]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[20]_inst 
       (.I(b[20]),
        .O(b_IBUF[20]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[21]_inst 
       (.I(b[21]),
        .O(b_IBUF[21]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[22]_inst 
       (.I(b[22]),
        .O(b_IBUF[22]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[23]_inst 
       (.I(b[23]),
        .O(b_IBUF[23]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[24]_inst 
       (.I(b[24]),
        .O(b_IBUF[24]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[25]_inst 
       (.I(b[25]),
        .O(b_IBUF[25]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[26]_inst 
       (.I(b[26]),
        .O(b_IBUF[26]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[27]_inst 
       (.I(b[27]),
        .O(b_IBUF[27]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[28]_inst 
       (.I(b[28]),
        .O(b_IBUF[28]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[29]_inst 
       (.I(b[29]),
        .O(b_IBUF[29]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[2]_inst 
       (.I(b[2]),
        .O(b_IBUF[2]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[30]_inst 
       (.I(b[30]),
        .O(b_IBUF[30]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[31]_inst 
       (.I(b[31]),
        .O(b_IBUF[31]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[3]_inst 
       (.I(b[3]),
        .O(b_IBUF[3]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[4]_inst 
       (.I(b[4]),
        .O(b_IBUF[4]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[5]_inst 
       (.I(b[5]),
        .O(b_IBUF[5]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[6]_inst 
       (.I(b[6]),
        .O(b_IBUF[6]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[7]_inst 
       (.I(b[7]),
        .O(b_IBUF[7]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[8]_inst 
       (.I(b[8]),
        .O(b_IBUF[8]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[9]_inst 
       (.I(b[9]),
        .O(b_IBUF[9]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    ci_IBUF_inst
       (.I(ci),
        .O(ci_IBUF));
  OBUF co_OBUF_inst
       (.I(co_OBUF),
        .O(co));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hCC9CCCCC)) 
    co_OBUF_inst_i_1
       (.I0(\s_OBUF[31]_inst_i_2_n_0 ),
        .I1(co_OBUF_inst_i_2_n_3),
        .I2(\s_OBUF[31]_inst_i_3_n_5 ),
        .I3(\s_OBUF[31]_inst_i_4_n_0 ),
        .I4(\s_OBUF[31]_inst_i_3_n_4 ),
        .O(co_OBUF));
  CARRY4 co_OBUF_inst_i_2
       (.CI(\s_OBUF[31]_inst_i_3_n_0 ),
        .CO({NLW_co_OBUF_inst_i_2_CO_UNCONNECTED[3:1],co_OBUF_inst_i_2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_co_OBUF_inst_i_2_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  OBUF \s_OBUF[0]_inst 
       (.I(s_OBUF[0]),
        .O(s[0]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[0]_inst_i_1 
       (.I0(ci_IBUF),
        .I1(sum0_0[0]),
        .O(s_OBUF[0]));
  OBUF \s_OBUF[10]_inst 
       (.I(s_OBUF[10]),
        .O(s[10]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hAA6A)) 
    \s_OBUF[10]_inst_i_1 
       (.I0(sum1_0[2]),
        .I1(sum1_0[1]),
        .I2(sum1_0[0]),
        .I3(\s_OBUF[15]_inst_i_2_n_0 ),
        .O(s_OBUF[10]));
  OBUF \s_OBUF[11]_inst 
       (.I(s_OBUF[11]),
        .O(s[11]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h9AAAAAAA)) 
    \s_OBUF[11]_inst_i_1 
       (.I0(sum1_0[3]),
        .I1(\s_OBUF[15]_inst_i_2_n_0 ),
        .I2(sum1_0[0]),
        .I3(sum1_0[1]),
        .I4(sum1_0[2]),
        .O(s_OBUF[11]));
  OBUF \s_OBUF[12]_inst 
       (.I(s_OBUF[12]),
        .O(s[12]));
  LUT6 #(
    .INIT(64'hAAAA6AAAAAAAAAAA)) 
    \s_OBUF[12]_inst_i_1 
       (.I0(sum1_0[4]),
        .I1(sum1_0[2]),
        .I2(sum1_0[1]),
        .I3(sum1_0[0]),
        .I4(\s_OBUF[15]_inst_i_2_n_0 ),
        .I5(sum1_0[3]),
        .O(s_OBUF[12]));
  CARRY4 \s_OBUF[12]_inst_i_2 
       (.CI(1'b0),
        .CO({\s_OBUF[12]_inst_i_2_n_0 ,\s_OBUF[12]_inst_i_2_n_1 ,\s_OBUF[12]_inst_i_2_n_2 ,\s_OBUF[12]_inst_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI(a_IBUF[11:8]),
        .O(sum1_0[3:0]),
        .S({\s_OBUF[12]_inst_i_3_n_0 ,\s_OBUF[12]_inst_i_4_n_0 ,\s_OBUF[12]_inst_i_5_n_0 ,\s_OBUF[12]_inst_i_6_n_0 }));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[12]_inst_i_3 
       (.I0(a_IBUF[11]),
        .I1(b_IBUF[11]),
        .O(\s_OBUF[12]_inst_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[12]_inst_i_4 
       (.I0(a_IBUF[10]),
        .I1(b_IBUF[10]),
        .O(\s_OBUF[12]_inst_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[12]_inst_i_5 
       (.I0(a_IBUF[9]),
        .I1(b_IBUF[9]),
        .O(\s_OBUF[12]_inst_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[12]_inst_i_6 
       (.I0(a_IBUF[8]),
        .I1(b_IBUF[8]),
        .O(\s_OBUF[12]_inst_i_6_n_0 ));
  OBUF \s_OBUF[13]_inst 
       (.I(s_OBUF[13]),
        .O(s[13]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hC9)) 
    \s_OBUF[13]_inst_i_1 
       (.I0(\s_OBUF[15]_inst_i_2_n_0 ),
        .I1(sum1_0[5]),
        .I2(\s_OBUF[13]_inst_i_2_n_0 ),
        .O(s_OBUF[13]));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \s_OBUF[13]_inst_i_2 
       (.I0(sum1_0[2]),
        .I1(sum1_0[0]),
        .I2(sum1_0[1]),
        .I3(sum1_0[3]),
        .I4(sum1_0[4]),
        .O(\s_OBUF[13]_inst_i_2_n_0 ));
  OBUF \s_OBUF[14]_inst 
       (.I(s_OBUF[14]),
        .O(s[14]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hC9)) 
    \s_OBUF[14]_inst_i_1 
       (.I0(\s_OBUF[15]_inst_i_2_n_0 ),
        .I1(sum1_0[6]),
        .I2(\s_OBUF[15]_inst_i_4_n_0 ),
        .O(s_OBUF[14]));
  OBUF \s_OBUF[15]_inst 
       (.I(s_OBUF[15]),
        .O(s[15]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'hC9CC)) 
    \s_OBUF[15]_inst_i_1 
       (.I0(\s_OBUF[15]_inst_i_2_n_0 ),
        .I1(sum1_0[7]),
        .I2(\s_OBUF[15]_inst_i_4_n_0 ),
        .I3(sum1_0[6]),
        .O(s_OBUF[15]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h95555555)) 
    \s_OBUF[15]_inst_i_2 
       (.I0(sum0_0[8]),
        .I1(sum0_0[7]),
        .I2(sum0_0[6]),
        .I3(sum0_0[5]),
        .I4(\s_OBUF[7]_inst_i_3_n_0 ),
        .O(\s_OBUF[15]_inst_i_2_n_0 ));
  CARRY4 \s_OBUF[15]_inst_i_3 
       (.CI(\s_OBUF[12]_inst_i_2_n_0 ),
        .CO({sum1_0[8],\s_OBUF[15]_inst_i_3_n_1 ,\s_OBUF[15]_inst_i_3_n_2 ,\s_OBUF[15]_inst_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI(a_IBUF[15:12]),
        .O(sum1_0[7:4]),
        .S({\s_OBUF[15]_inst_i_6_n_0 ,\s_OBUF[15]_inst_i_7_n_0 ,\s_OBUF[15]_inst_i_8_n_0 ,\s_OBUF[15]_inst_i_9_n_0 }));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    \s_OBUF[15]_inst_i_4 
       (.I0(sum1_0[4]),
        .I1(sum1_0[3]),
        .I2(sum1_0[1]),
        .I3(sum1_0[0]),
        .I4(sum1_0[2]),
        .I5(sum1_0[5]),
        .O(\s_OBUF[15]_inst_i_4_n_0 ));
  CARRY4 \s_OBUF[15]_inst_i_5 
       (.CI(\s_OBUF[7]_inst_i_2_n_0 ),
        .CO({\NLW_s_OBUF[15]_inst_i_5_CO_UNCONNECTED [3:1],sum0_0[8]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_s_OBUF[15]_inst_i_5_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[15]_inst_i_6 
       (.I0(a_IBUF[15]),
        .I1(b_IBUF[15]),
        .O(\s_OBUF[15]_inst_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[15]_inst_i_7 
       (.I0(a_IBUF[14]),
        .I1(b_IBUF[14]),
        .O(\s_OBUF[15]_inst_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[15]_inst_i_8 
       (.I0(a_IBUF[13]),
        .I1(b_IBUF[13]),
        .O(\s_OBUF[15]_inst_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[15]_inst_i_9 
       (.I0(a_IBUF[12]),
        .I1(b_IBUF[12]),
        .O(\s_OBUF[15]_inst_i_9_n_0 ));
  OBUF \s_OBUF[16]_inst 
       (.I(s_OBUF[16]),
        .O(s[16]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \s_OBUF[16]_inst_i_1 
       (.I0(\s_OBUF[23]_inst_i_2_n_0 ),
        .I1(sum2_0[0]),
        .O(s_OBUF[16]));
  OBUF \s_OBUF[17]_inst 
       (.I(s_OBUF[17]),
        .O(s[17]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'h9A)) 
    \s_OBUF[17]_inst_i_1 
       (.I0(sum2_0[1]),
        .I1(\s_OBUF[23]_inst_i_2_n_0 ),
        .I2(sum2_0[0]),
        .O(s_OBUF[17]));
  OBUF \s_OBUF[18]_inst 
       (.I(s_OBUF[18]),
        .O(s[18]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'hAA6A)) 
    \s_OBUF[18]_inst_i_1 
       (.I0(sum2_0[2]),
        .I1(sum2_0[1]),
        .I2(sum2_0[0]),
        .I3(\s_OBUF[23]_inst_i_2_n_0 ),
        .O(s_OBUF[18]));
  OBUF \s_OBUF[19]_inst 
       (.I(s_OBUF[19]),
        .O(s[19]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h9CCCCCCC)) 
    \s_OBUF[19]_inst_i_1 
       (.I0(\s_OBUF[23]_inst_i_2_n_0 ),
        .I1(sum2_0[3]),
        .I2(sum2_0[1]),
        .I3(sum2_0[0]),
        .I4(sum2_0[2]),
        .O(s_OBUF[19]));
  OBUF \s_OBUF[1]_inst 
       (.I(s_OBUF[1]),
        .O(s[1]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'h6A)) 
    \s_OBUF[1]_inst_i_1 
       (.I0(sum0_0[1]),
        .I1(ci_IBUF),
        .I2(sum0_0[0]),
        .O(s_OBUF[1]));
  OBUF \s_OBUF[20]_inst 
       (.I(s_OBUF[20]),
        .O(s[20]));
  LUT6 #(
    .INIT(64'h9CCCCCCCCCCCCCCC)) 
    \s_OBUF[20]_inst_i_1 
       (.I0(\s_OBUF[23]_inst_i_2_n_0 ),
        .I1(sum2_0[4]),
        .I2(sum2_0[2]),
        .I3(sum2_0[0]),
        .I4(sum2_0[1]),
        .I5(sum2_0[3]),
        .O(s_OBUF[20]));
  CARRY4 \s_OBUF[20]_inst_i_2 
       (.CI(1'b0),
        .CO({\s_OBUF[20]_inst_i_2_n_0 ,\s_OBUF[20]_inst_i_2_n_1 ,\s_OBUF[20]_inst_i_2_n_2 ,\s_OBUF[20]_inst_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI(a_IBUF[19:16]),
        .O(sum2_0[3:0]),
        .S({\s_OBUF[20]_inst_i_3_n_0 ,\s_OBUF[20]_inst_i_4_n_0 ,\s_OBUF[20]_inst_i_5_n_0 ,\s_OBUF[20]_inst_i_6_n_0 }));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[20]_inst_i_3 
       (.I0(a_IBUF[19]),
        .I1(b_IBUF[19]),
        .O(\s_OBUF[20]_inst_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[20]_inst_i_4 
       (.I0(a_IBUF[18]),
        .I1(b_IBUF[18]),
        .O(\s_OBUF[20]_inst_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[20]_inst_i_5 
       (.I0(a_IBUF[17]),
        .I1(b_IBUF[17]),
        .O(\s_OBUF[20]_inst_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[20]_inst_i_6 
       (.I0(a_IBUF[16]),
        .I1(b_IBUF[16]),
        .O(\s_OBUF[20]_inst_i_6_n_0 ));
  OBUF \s_OBUF[21]_inst 
       (.I(s_OBUF[21]),
        .O(s[21]));
  LUT3 #(
    .INIT(8'hA9)) 
    \s_OBUF[21]_inst_i_1 
       (.I0(sum2_0[5]),
        .I1(\s_OBUF[21]_inst_i_2_n_0 ),
        .I2(\s_OBUF[23]_inst_i_2_n_0 ),
        .O(s_OBUF[21]));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \s_OBUF[21]_inst_i_2 
       (.I0(sum2_0[2]),
        .I1(sum2_0[0]),
        .I2(sum2_0[1]),
        .I3(sum2_0[3]),
        .I4(sum2_0[4]),
        .O(\s_OBUF[21]_inst_i_2_n_0 ));
  OBUF \s_OBUF[22]_inst 
       (.I(s_OBUF[22]),
        .O(s[22]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hA9)) 
    \s_OBUF[22]_inst_i_1 
       (.I0(sum2_0[6]),
        .I1(\s_OBUF[23]_inst_i_4_n_0 ),
        .I2(\s_OBUF[23]_inst_i_2_n_0 ),
        .O(s_OBUF[22]));
  OBUF \s_OBUF[23]_inst 
       (.I(s_OBUF[23]),
        .O(s[23]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'hC9CC)) 
    \s_OBUF[23]_inst_i_1 
       (.I0(\s_OBUF[23]_inst_i_2_n_0 ),
        .I1(sum2_0[7]),
        .I2(\s_OBUF[23]_inst_i_4_n_0 ),
        .I3(sum2_0[6]),
        .O(s_OBUF[23]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'hCC9CCCCC)) 
    \s_OBUF[23]_inst_i_2 
       (.I0(\s_OBUF[15]_inst_i_2_n_0 ),
        .I1(\s_OBUF[31]_inst_i_6_n_7 ),
        .I2(sum1_0[6]),
        .I3(\s_OBUF[15]_inst_i_4_n_0 ),
        .I4(sum1_0[7]),
        .O(\s_OBUF[23]_inst_i_2_n_0 ));
  CARRY4 \s_OBUF[23]_inst_i_3 
       (.CI(\s_OBUF[20]_inst_i_2_n_0 ),
        .CO({sum2_0[8],\s_OBUF[23]_inst_i_3_n_1 ,\s_OBUF[23]_inst_i_3_n_2 ,\s_OBUF[23]_inst_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI(a_IBUF[23:20]),
        .O(sum2_0[7:4]),
        .S({\s_OBUF[23]_inst_i_5_n_0 ,\s_OBUF[23]_inst_i_6_n_0 ,\s_OBUF[23]_inst_i_7_n_0 ,\s_OBUF[23]_inst_i_8_n_0 }));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    \s_OBUF[23]_inst_i_4 
       (.I0(sum2_0[4]),
        .I1(sum2_0[3]),
        .I2(sum2_0[1]),
        .I3(sum2_0[0]),
        .I4(sum2_0[2]),
        .I5(sum2_0[5]),
        .O(\s_OBUF[23]_inst_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[23]_inst_i_5 
       (.I0(a_IBUF[23]),
        .I1(b_IBUF[23]),
        .O(\s_OBUF[23]_inst_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[23]_inst_i_6 
       (.I0(a_IBUF[22]),
        .I1(b_IBUF[22]),
        .O(\s_OBUF[23]_inst_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[23]_inst_i_7 
       (.I0(a_IBUF[21]),
        .I1(b_IBUF[21]),
        .O(\s_OBUF[23]_inst_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[23]_inst_i_8 
       (.I0(a_IBUF[20]),
        .I1(b_IBUF[20]),
        .O(\s_OBUF[23]_inst_i_8_n_0 ));
  OBUF \s_OBUF[24]_inst 
       (.I(s_OBUF[24]),
        .O(s[24]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \s_OBUF[24]_inst_i_1 
       (.I0(\s_OBUF[28]_inst_i_2_n_7 ),
        .I1(\s_OBUF[31]_inst_i_2_n_0 ),
        .O(s_OBUF[24]));
  OBUF \s_OBUF[25]_inst 
       (.I(s_OBUF[25]),
        .O(s[25]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'h9C)) 
    \s_OBUF[25]_inst_i_1 
       (.I0(\s_OBUF[31]_inst_i_2_n_0 ),
        .I1(\s_OBUF[28]_inst_i_2_n_6 ),
        .I2(\s_OBUF[28]_inst_i_2_n_7 ),
        .O(s_OBUF[25]));
  OBUF \s_OBUF[26]_inst 
       (.I(s_OBUF[26]),
        .O(s[26]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h9CCC)) 
    \s_OBUF[26]_inst_i_1 
       (.I0(\s_OBUF[31]_inst_i_2_n_0 ),
        .I1(\s_OBUF[28]_inst_i_2_n_5 ),
        .I2(\s_OBUF[28]_inst_i_2_n_6 ),
        .I3(\s_OBUF[28]_inst_i_2_n_7 ),
        .O(s_OBUF[26]));
  OBUF \s_OBUF[27]_inst 
       (.I(s_OBUF[27]),
        .O(s[27]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h9CCCCCCC)) 
    \s_OBUF[27]_inst_i_1 
       (.I0(\s_OBUF[31]_inst_i_2_n_0 ),
        .I1(\s_OBUF[28]_inst_i_2_n_4 ),
        .I2(\s_OBUF[28]_inst_i_2_n_7 ),
        .I3(\s_OBUF[28]_inst_i_2_n_6 ),
        .I4(\s_OBUF[28]_inst_i_2_n_5 ),
        .O(s_OBUF[27]));
  OBUF \s_OBUF[28]_inst 
       (.I(s_OBUF[28]),
        .O(s[28]));
  LUT6 #(
    .INIT(64'h9CCCCCCCCCCCCCCC)) 
    \s_OBUF[28]_inst_i_1 
       (.I0(\s_OBUF[31]_inst_i_2_n_0 ),
        .I1(\s_OBUF[31]_inst_i_3_n_7 ),
        .I2(\s_OBUF[28]_inst_i_2_n_5 ),
        .I3(\s_OBUF[28]_inst_i_2_n_6 ),
        .I4(\s_OBUF[28]_inst_i_2_n_7 ),
        .I5(\s_OBUF[28]_inst_i_2_n_4 ),
        .O(s_OBUF[28]));
  CARRY4 \s_OBUF[28]_inst_i_2 
       (.CI(1'b0),
        .CO({\s_OBUF[28]_inst_i_2_n_0 ,\s_OBUF[28]_inst_i_2_n_1 ,\s_OBUF[28]_inst_i_2_n_2 ,\s_OBUF[28]_inst_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI(a_IBUF[27:24]),
        .O({\s_OBUF[28]_inst_i_2_n_4 ,\s_OBUF[28]_inst_i_2_n_5 ,\s_OBUF[28]_inst_i_2_n_6 ,\s_OBUF[28]_inst_i_2_n_7 }),
        .S({\s_OBUF[28]_inst_i_3_n_0 ,\s_OBUF[28]_inst_i_4_n_0 ,\s_OBUF[28]_inst_i_5_n_0 ,\s_OBUF[28]_inst_i_6_n_0 }));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[28]_inst_i_3 
       (.I0(a_IBUF[27]),
        .I1(b_IBUF[27]),
        .O(\s_OBUF[28]_inst_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[28]_inst_i_4 
       (.I0(a_IBUF[26]),
        .I1(b_IBUF[26]),
        .O(\s_OBUF[28]_inst_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[28]_inst_i_5 
       (.I0(a_IBUF[25]),
        .I1(b_IBUF[25]),
        .O(\s_OBUF[28]_inst_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[28]_inst_i_6 
       (.I0(a_IBUF[24]),
        .I1(b_IBUF[24]),
        .O(\s_OBUF[28]_inst_i_6_n_0 ));
  OBUF \s_OBUF[29]_inst 
       (.I(s_OBUF[29]),
        .O(s[29]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hC9)) 
    \s_OBUF[29]_inst_i_1 
       (.I0(\s_OBUF[31]_inst_i_2_n_0 ),
        .I1(\s_OBUF[31]_inst_i_3_n_6 ),
        .I2(\s_OBUF[29]_inst_i_2_n_0 ),
        .O(s_OBUF[29]));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \s_OBUF[29]_inst_i_2 
       (.I0(\s_OBUF[28]_inst_i_2_n_4 ),
        .I1(\s_OBUF[28]_inst_i_2_n_7 ),
        .I2(\s_OBUF[28]_inst_i_2_n_6 ),
        .I3(\s_OBUF[28]_inst_i_2_n_5 ),
        .I4(\s_OBUF[31]_inst_i_3_n_7 ),
        .O(\s_OBUF[29]_inst_i_2_n_0 ));
  OBUF \s_OBUF[2]_inst 
       (.I(s_OBUF[2]),
        .O(s[2]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'h6AAA)) 
    \s_OBUF[2]_inst_i_1 
       (.I0(sum0_0[2]),
        .I1(sum0_0[1]),
        .I2(ci_IBUF),
        .I3(sum0_0[0]),
        .O(s_OBUF[2]));
  OBUF \s_OBUF[30]_inst 
       (.I(s_OBUF[30]),
        .O(s[30]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hE1)) 
    \s_OBUF[30]_inst_i_1 
       (.I0(\s_OBUF[31]_inst_i_2_n_0 ),
        .I1(\s_OBUF[31]_inst_i_4_n_0 ),
        .I2(\s_OBUF[31]_inst_i_3_n_5 ),
        .O(s_OBUF[30]));
  OBUF \s_OBUF[31]_inst 
       (.I(s_OBUF[31]),
        .O(s[31]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hC9CC)) 
    \s_OBUF[31]_inst_i_1 
       (.I0(\s_OBUF[31]_inst_i_2_n_0 ),
        .I1(\s_OBUF[31]_inst_i_3_n_4 ),
        .I2(\s_OBUF[31]_inst_i_4_n_0 ),
        .I3(\s_OBUF[31]_inst_i_3_n_5 ),
        .O(s_OBUF[31]));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[31]_inst_i_10 
       (.I0(a_IBUF[30]),
        .I1(b_IBUF[30]),
        .O(\s_OBUF[31]_inst_i_10_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[31]_inst_i_11 
       (.I0(a_IBUF[29]),
        .I1(b_IBUF[29]),
        .O(\s_OBUF[31]_inst_i_11_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[31]_inst_i_12 
       (.I0(a_IBUF[28]),
        .I1(b_IBUF[28]),
        .O(\s_OBUF[31]_inst_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hBEAFAFAF82A0A0A0)) 
    \s_OBUF[31]_inst_i_2 
       (.I0(\s_OBUF[31]_inst_i_5_n_7 ),
        .I1(\s_OBUF[15]_inst_i_2_n_0 ),
        .I2(\s_OBUF[31]_inst_i_6_n_7 ),
        .I3(\s_OBUF[31]_inst_i_7_n_0 ),
        .I4(sum1_0[7]),
        .I5(\s_OBUF[31]_inst_i_8_n_0 ),
        .O(\s_OBUF[31]_inst_i_2_n_0 ));
  CARRY4 \s_OBUF[31]_inst_i_3 
       (.CI(\s_OBUF[28]_inst_i_2_n_0 ),
        .CO({\s_OBUF[31]_inst_i_3_n_0 ,\s_OBUF[31]_inst_i_3_n_1 ,\s_OBUF[31]_inst_i_3_n_2 ,\s_OBUF[31]_inst_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI(a_IBUF[31:28]),
        .O({\s_OBUF[31]_inst_i_3_n_4 ,\s_OBUF[31]_inst_i_3_n_5 ,\s_OBUF[31]_inst_i_3_n_6 ,\s_OBUF[31]_inst_i_3_n_7 }),
        .S({\s_OBUF[31]_inst_i_9_n_0 ,\s_OBUF[31]_inst_i_10_n_0 ,\s_OBUF[31]_inst_i_11_n_0 ,\s_OBUF[31]_inst_i_12_n_0 }));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    \s_OBUF[31]_inst_i_4 
       (.I0(\s_OBUF[31]_inst_i_3_n_7 ),
        .I1(\s_OBUF[28]_inst_i_2_n_5 ),
        .I2(\s_OBUF[28]_inst_i_2_n_6 ),
        .I3(\s_OBUF[28]_inst_i_2_n_7 ),
        .I4(\s_OBUF[28]_inst_i_2_n_4 ),
        .I5(\s_OBUF[31]_inst_i_3_n_6 ),
        .O(\s_OBUF[31]_inst_i_4_n_0 ));
  CARRY4 \s_OBUF[31]_inst_i_5 
       (.CI(sum2_0[8]),
        .CO(\NLW_s_OBUF[31]_inst_i_5_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_s_OBUF[31]_inst_i_5_O_UNCONNECTED [3:1],\s_OBUF[31]_inst_i_5_n_7 }),
        .S({1'b0,1'b0,1'b0,1'b1}));
  CARRY4 \s_OBUF[31]_inst_i_6 
       (.CI(sum1_0[8]),
        .CO(\NLW_s_OBUF[31]_inst_i_6_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_s_OBUF[31]_inst_i_6_O_UNCONNECTED [3:1],\s_OBUF[31]_inst_i_6_n_7 }),
        .S({1'b0,1'b0,1'b0,1'b1}));
  LUT2 #(
    .INIT(4'h2)) 
    \s_OBUF[31]_inst_i_7 
       (.I0(sum1_0[6]),
        .I1(\s_OBUF[15]_inst_i_4_n_0 ),
        .O(\s_OBUF[31]_inst_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hA6AA)) 
    \s_OBUF[31]_inst_i_8 
       (.I0(\s_OBUF[31]_inst_i_5_n_7 ),
        .I1(sum2_0[6]),
        .I2(\s_OBUF[23]_inst_i_4_n_0 ),
        .I3(sum2_0[7]),
        .O(\s_OBUF[31]_inst_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[31]_inst_i_9 
       (.I0(a_IBUF[31]),
        .I1(b_IBUF[31]),
        .O(\s_OBUF[31]_inst_i_9_n_0 ));
  OBUF \s_OBUF[3]_inst 
       (.I(s_OBUF[3]),
        .O(s[3]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \s_OBUF[3]_inst_i_1 
       (.I0(sum0_0[3]),
        .I1(sum0_0[2]),
        .I2(sum0_0[0]),
        .I3(ci_IBUF),
        .I4(sum0_0[1]),
        .O(s_OBUF[3]));
  OBUF \s_OBUF[4]_inst 
       (.I(s_OBUF[4]),
        .O(s[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \s_OBUF[4]_inst_i_1 
       (.I0(sum0_0[2]),
        .I1(sum0_0[0]),
        .I2(ci_IBUF),
        .I3(sum0_0[1]),
        .I4(sum0_0[3]),
        .I5(sum0_0[4]),
        .O(s_OBUF[4]));
  CARRY4 \s_OBUF[4]_inst_i_2 
       (.CI(1'b0),
        .CO({\s_OBUF[4]_inst_i_2_n_0 ,\s_OBUF[4]_inst_i_2_n_1 ,\s_OBUF[4]_inst_i_2_n_2 ,\s_OBUF[4]_inst_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI(a_IBUF[3:0]),
        .O(sum0_0[3:0]),
        .S({\s_OBUF[4]_inst_i_3_n_0 ,\s_OBUF[4]_inst_i_4_n_0 ,\s_OBUF[4]_inst_i_5_n_0 ,\s_OBUF[4]_inst_i_6_n_0 }));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[4]_inst_i_3 
       (.I0(a_IBUF[3]),
        .I1(b_IBUF[3]),
        .O(\s_OBUF[4]_inst_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[4]_inst_i_4 
       (.I0(a_IBUF[2]),
        .I1(b_IBUF[2]),
        .O(\s_OBUF[4]_inst_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[4]_inst_i_5 
       (.I0(a_IBUF[1]),
        .I1(b_IBUF[1]),
        .O(\s_OBUF[4]_inst_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[4]_inst_i_6 
       (.I0(a_IBUF[0]),
        .I1(b_IBUF[0]),
        .O(\s_OBUF[4]_inst_i_6_n_0 ));
  OBUF \s_OBUF[5]_inst 
       (.I(s_OBUF[5]),
        .O(s[5]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[5]_inst_i_1 
       (.I0(sum0_0[5]),
        .I1(\s_OBUF[7]_inst_i_3_n_0 ),
        .O(s_OBUF[5]));
  OBUF \s_OBUF[6]_inst 
       (.I(s_OBUF[6]),
        .O(s[6]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'h6A)) 
    \s_OBUF[6]_inst_i_1 
       (.I0(sum0_0[6]),
        .I1(sum0_0[5]),
        .I2(\s_OBUF[7]_inst_i_3_n_0 ),
        .O(s_OBUF[6]));
  OBUF \s_OBUF[7]_inst 
       (.I(s_OBUF[7]),
        .O(s[7]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h6AAA)) 
    \s_OBUF[7]_inst_i_1 
       (.I0(sum0_0[7]),
        .I1(sum0_0[6]),
        .I2(sum0_0[5]),
        .I3(\s_OBUF[7]_inst_i_3_n_0 ),
        .O(s_OBUF[7]));
  CARRY4 \s_OBUF[7]_inst_i_2 
       (.CI(\s_OBUF[4]_inst_i_2_n_0 ),
        .CO({\s_OBUF[7]_inst_i_2_n_0 ,\s_OBUF[7]_inst_i_2_n_1 ,\s_OBUF[7]_inst_i_2_n_2 ,\s_OBUF[7]_inst_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI(a_IBUF[7:4]),
        .O(sum0_0[7:4]),
        .S({\s_OBUF[7]_inst_i_4_n_0 ,\s_OBUF[7]_inst_i_5_n_0 ,\s_OBUF[7]_inst_i_6_n_0 ,\s_OBUF[7]_inst_i_7_n_0 }));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \s_OBUF[7]_inst_i_3 
       (.I0(sum0_0[4]),
        .I1(sum0_0[3]),
        .I2(sum0_0[1]),
        .I3(ci_IBUF),
        .I4(sum0_0[0]),
        .I5(sum0_0[2]),
        .O(\s_OBUF[7]_inst_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[7]_inst_i_4 
       (.I0(a_IBUF[7]),
        .I1(b_IBUF[7]),
        .O(\s_OBUF[7]_inst_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[7]_inst_i_5 
       (.I0(a_IBUF[6]),
        .I1(b_IBUF[6]),
        .O(\s_OBUF[7]_inst_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[7]_inst_i_6 
       (.I0(a_IBUF[5]),
        .I1(b_IBUF[5]),
        .O(\s_OBUF[7]_inst_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \s_OBUF[7]_inst_i_7 
       (.I0(a_IBUF[4]),
        .I1(b_IBUF[4]),
        .O(\s_OBUF[7]_inst_i_7_n_0 ));
  OBUF \s_OBUF[8]_inst 
       (.I(s_OBUF[8]),
        .O(s[8]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \s_OBUF[8]_inst_i_1 
       (.I0(sum1_0[0]),
        .I1(\s_OBUF[15]_inst_i_2_n_0 ),
        .O(s_OBUF[8]));
  OBUF \s_OBUF[9]_inst 
       (.I(s_OBUF[9]),
        .O(s[9]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'h9A)) 
    \s_OBUF[9]_inst_i_1 
       (.I0(sum1_0[1]),
        .I1(\s_OBUF[15]_inst_i_2_n_0 ),
        .I2(sum1_0[0]),
        .O(s_OBUF[9]));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
