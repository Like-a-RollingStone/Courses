// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
// Date        : Tue Sep 30 20:54:22 2025
// Host        : DESKTOP-3MS8VAT running 64-bit major release  (build 9200)
// Command     : write_verilog -mode timesim -nolib -sdf_anno true -force -file
//               C:/Users/PC/Desktop/VivadoProjects/lab8_3/lab8_3.sim/sim_1/impl/timing/modelsim/pipeline_adder_tb_time_impl.v
// Design      : pipeline_adder
// Purpose     : This verilog netlist is a timing simulation representation of the design and should not be modified or
//               synthesized. Please ensure that this netlist is used with the corresponding SDF file.
// Device      : xc7a200tfbg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps
`define XIL_TIMING

(* ECO_CHECKSUM = "7498acc9" *) 
(* NotValidForBitStream *)
module pipeline_adder
   (clk,
    a,
    b,
    ci,
    s,
    co);
  input clk;
  input [31:0]a;
  input [31:0]b;
  input ci;
  output [31:0]s;
  output co;

  wire [31:0]a;
  wire [31:0]a_IBUF;
  wire [31:0]b;
  wire [31:0]b_IBUF;
  wire ci;
  wire ci_IBUF;
  wire clk;
  wire clk_IBUF;
  wire clk_IBUF_BUFG;
  wire co;
  wire co_OBUF;
  wire cout;
  wire [31:0]reg_a;
  wire [31:0]reg_b;
  wire reg_ci;
  wire \reg_s[11]_i_2_n_0 ;
  wire \reg_s[11]_i_3_n_0 ;
  wire \reg_s[11]_i_4_n_0 ;
  wire \reg_s[11]_i_5_n_0 ;
  wire \reg_s[15]_i_2_n_0 ;
  wire \reg_s[15]_i_3_n_0 ;
  wire \reg_s[15]_i_4_n_0 ;
  wire \reg_s[15]_i_5_n_0 ;
  wire \reg_s[19]_i_2_n_0 ;
  wire \reg_s[19]_i_3_n_0 ;
  wire \reg_s[19]_i_4_n_0 ;
  wire \reg_s[19]_i_5_n_0 ;
  wire \reg_s[23]_i_2_n_0 ;
  wire \reg_s[23]_i_3_n_0 ;
  wire \reg_s[23]_i_4_n_0 ;
  wire \reg_s[23]_i_5_n_0 ;
  wire \reg_s[27]_i_2_n_0 ;
  wire \reg_s[27]_i_3_n_0 ;
  wire \reg_s[27]_i_4_n_0 ;
  wire \reg_s[27]_i_5_n_0 ;
  wire \reg_s[31]_i_2_n_0 ;
  wire \reg_s[31]_i_3_n_0 ;
  wire \reg_s[31]_i_4_n_0 ;
  wire \reg_s[31]_i_5_n_0 ;
  wire \reg_s[3]_i_2_n_0 ;
  wire \reg_s[3]_i_3_n_0 ;
  wire \reg_s[3]_i_4_n_0 ;
  wire \reg_s[3]_i_5_n_0 ;
  wire \reg_s[7]_i_2_n_0 ;
  wire \reg_s[7]_i_3_n_0 ;
  wire \reg_s[7]_i_4_n_0 ;
  wire \reg_s[7]_i_5_n_0 ;
  wire \reg_s_reg[11]_i_1_n_0 ;
  wire \reg_s_reg[11]_i_1_n_4 ;
  wire \reg_s_reg[11]_i_1_n_5 ;
  wire \reg_s_reg[11]_i_1_n_6 ;
  wire \reg_s_reg[11]_i_1_n_7 ;
  wire \reg_s_reg[15]_i_1_n_0 ;
  wire \reg_s_reg[15]_i_1_n_4 ;
  wire \reg_s_reg[15]_i_1_n_5 ;
  wire \reg_s_reg[15]_i_1_n_6 ;
  wire \reg_s_reg[15]_i_1_n_7 ;
  wire \reg_s_reg[19]_i_1_n_0 ;
  wire \reg_s_reg[19]_i_1_n_4 ;
  wire \reg_s_reg[19]_i_1_n_5 ;
  wire \reg_s_reg[19]_i_1_n_6 ;
  wire \reg_s_reg[19]_i_1_n_7 ;
  wire \reg_s_reg[23]_i_1_n_0 ;
  wire \reg_s_reg[23]_i_1_n_4 ;
  wire \reg_s_reg[23]_i_1_n_5 ;
  wire \reg_s_reg[23]_i_1_n_6 ;
  wire \reg_s_reg[23]_i_1_n_7 ;
  wire \reg_s_reg[27]_i_1_n_0 ;
  wire \reg_s_reg[27]_i_1_n_4 ;
  wire \reg_s_reg[27]_i_1_n_5 ;
  wire \reg_s_reg[27]_i_1_n_6 ;
  wire \reg_s_reg[27]_i_1_n_7 ;
  wire \reg_s_reg[31]_i_1_n_0 ;
  wire \reg_s_reg[31]_i_1_n_4 ;
  wire \reg_s_reg[31]_i_1_n_5 ;
  wire \reg_s_reg[31]_i_1_n_6 ;
  wire \reg_s_reg[31]_i_1_n_7 ;
  wire \reg_s_reg[3]_i_1_n_0 ;
  wire \reg_s_reg[3]_i_1_n_4 ;
  wire \reg_s_reg[3]_i_1_n_5 ;
  wire \reg_s_reg[3]_i_1_n_6 ;
  wire \reg_s_reg[3]_i_1_n_7 ;
  wire \reg_s_reg[7]_i_1_n_0 ;
  wire \reg_s_reg[7]_i_1_n_4 ;
  wire \reg_s_reg[7]_i_1_n_5 ;
  wire \reg_s_reg[7]_i_1_n_6 ;
  wire \reg_s_reg[7]_i_1_n_7 ;
  wire [31:0]s;
  wire [31:0]s_OBUF;
  wire [3:1]NLW_reg_co_reg_i_1_CO_UNCONNECTED;
  wire [3:0]NLW_reg_co_reg_i_1_O_UNCONNECTED;
  wire [2:0]\NLW_reg_s_reg[11]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_reg_s_reg[15]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_reg_s_reg[19]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_reg_s_reg[23]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_reg_s_reg[27]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_reg_s_reg[31]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_reg_s_reg[3]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_reg_s_reg[7]_i_1_CO_UNCONNECTED ;

initial begin
 $sdf_annotate("pipeline_adder_tb_time_impl.sdf",,,,"tool_control");
end
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[0]_inst 
       (.I(a[0]),
        .O(a_IBUF[0]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[10]_inst 
       (.I(a[10]),
        .O(a_IBUF[10]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[11]_inst 
       (.I(a[11]),
        .O(a_IBUF[11]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[12]_inst 
       (.I(a[12]),
        .O(a_IBUF[12]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[13]_inst 
       (.I(a[13]),
        .O(a_IBUF[13]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[14]_inst 
       (.I(a[14]),
        .O(a_IBUF[14]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[15]_inst 
       (.I(a[15]),
        .O(a_IBUF[15]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[16]_inst 
       (.I(a[16]),
        .O(a_IBUF[16]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[17]_inst 
       (.I(a[17]),
        .O(a_IBUF[17]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[18]_inst 
       (.I(a[18]),
        .O(a_IBUF[18]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[19]_inst 
       (.I(a[19]),
        .O(a_IBUF[19]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[1]_inst 
       (.I(a[1]),
        .O(a_IBUF[1]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[20]_inst 
       (.I(a[20]),
        .O(a_IBUF[20]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[21]_inst 
       (.I(a[21]),
        .O(a_IBUF[21]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[22]_inst 
       (.I(a[22]),
        .O(a_IBUF[22]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[23]_inst 
       (.I(a[23]),
        .O(a_IBUF[23]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[24]_inst 
       (.I(a[24]),
        .O(a_IBUF[24]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[25]_inst 
       (.I(a[25]),
        .O(a_IBUF[25]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[26]_inst 
       (.I(a[26]),
        .O(a_IBUF[26]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[27]_inst 
       (.I(a[27]),
        .O(a_IBUF[27]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[28]_inst 
       (.I(a[28]),
        .O(a_IBUF[28]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[29]_inst 
       (.I(a[29]),
        .O(a_IBUF[29]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[2]_inst 
       (.I(a[2]),
        .O(a_IBUF[2]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[30]_inst 
       (.I(a[30]),
        .O(a_IBUF[30]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[31]_inst 
       (.I(a[31]),
        .O(a_IBUF[31]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[3]_inst 
       (.I(a[3]),
        .O(a_IBUF[3]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[4]_inst 
       (.I(a[4]),
        .O(a_IBUF[4]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[5]_inst 
       (.I(a[5]),
        .O(a_IBUF[5]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[6]_inst 
       (.I(a[6]),
        .O(a_IBUF[6]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[7]_inst 
       (.I(a[7]),
        .O(a_IBUF[7]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[8]_inst 
       (.I(a[8]),
        .O(a_IBUF[8]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \a_IBUF[9]_inst 
       (.I(a[9]),
        .O(a_IBUF[9]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[0]_inst 
       (.I(b[0]),
        .O(b_IBUF[0]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[10]_inst 
       (.I(b[10]),
        .O(b_IBUF[10]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[11]_inst 
       (.I(b[11]),
        .O(b_IBUF[11]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[12]_inst 
       (.I(b[12]),
        .O(b_IBUF[12]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[13]_inst 
       (.I(b[13]),
        .O(b_IBUF[13]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[14]_inst 
       (.I(b[14]),
        .O(b_IBUF[14]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[15]_inst 
       (.I(b[15]),
        .O(b_IBUF[15]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[16]_inst 
       (.I(b[16]),
        .O(b_IBUF[16]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[17]_inst 
       (.I(b[17]),
        .O(b_IBUF[17]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[18]_inst 
       (.I(b[18]),
        .O(b_IBUF[18]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[19]_inst 
       (.I(b[19]),
        .O(b_IBUF[19]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[1]_inst 
       (.I(b[1]),
        .O(b_IBUF[1]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[20]_inst 
       (.I(b[20]),
        .O(b_IBUF[20]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[21]_inst 
       (.I(b[21]),
        .O(b_IBUF[21]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[22]_inst 
       (.I(b[22]),
        .O(b_IBUF[22]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[23]_inst 
       (.I(b[23]),
        .O(b_IBUF[23]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[24]_inst 
       (.I(b[24]),
        .O(b_IBUF[24]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[25]_inst 
       (.I(b[25]),
        .O(b_IBUF[25]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[26]_inst 
       (.I(b[26]),
        .O(b_IBUF[26]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[27]_inst 
       (.I(b[27]),
        .O(b_IBUF[27]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[28]_inst 
       (.I(b[28]),
        .O(b_IBUF[28]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[29]_inst 
       (.I(b[29]),
        .O(b_IBUF[29]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[2]_inst 
       (.I(b[2]),
        .O(b_IBUF[2]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[30]_inst 
       (.I(b[30]),
        .O(b_IBUF[30]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[31]_inst 
       (.I(b[31]),
        .O(b_IBUF[31]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[3]_inst 
       (.I(b[3]),
        .O(b_IBUF[3]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[4]_inst 
       (.I(b[4]),
        .O(b_IBUF[4]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[5]_inst 
       (.I(b[5]),
        .O(b_IBUF[5]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[6]_inst 
       (.I(b[6]),
        .O(b_IBUF[6]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[7]_inst 
       (.I(b[7]),
        .O(b_IBUF[7]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[8]_inst 
       (.I(b[8]),
        .O(b_IBUF[8]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    \b_IBUF[9]_inst 
       (.I(b[9]),
        .O(b_IBUF[9]));
  IBUF #(
    .CCIO_EN("TRUE")) 
    ci_IBUF_inst
       (.I(ci),
        .O(ci_IBUF));
  BUFG clk_IBUF_BUFG_inst
       (.I(clk_IBUF),
        .O(clk_IBUF_BUFG));
  IBUF #(
    .CCIO_EN("TRUE")) 
    clk_IBUF_inst
       (.I(clk),
        .O(clk_IBUF));
  OBUF co_OBUF_inst
       (.I(co_OBUF),
        .O(co));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[0]),
        .Q(reg_a[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[10]),
        .Q(reg_a[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[11]),
        .Q(reg_a[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[12] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[12]),
        .Q(reg_a[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[13] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[13]),
        .Q(reg_a[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[14] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[14]),
        .Q(reg_a[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[15] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[15]),
        .Q(reg_a[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[16] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[16]),
        .Q(reg_a[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[17] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[17]),
        .Q(reg_a[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[18] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[18]),
        .Q(reg_a[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[19] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[19]),
        .Q(reg_a[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[1]),
        .Q(reg_a[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[20] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[20]),
        .Q(reg_a[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[21] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[21]),
        .Q(reg_a[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[22] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[22]),
        .Q(reg_a[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[23] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[23]),
        .Q(reg_a[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[24] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[24]),
        .Q(reg_a[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[25] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[25]),
        .Q(reg_a[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[26] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[26]),
        .Q(reg_a[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[27] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[27]),
        .Q(reg_a[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[28] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[28]),
        .Q(reg_a[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[29] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[29]),
        .Q(reg_a[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[2]),
        .Q(reg_a[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[30] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[30]),
        .Q(reg_a[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[31] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[31]),
        .Q(reg_a[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[3]),
        .Q(reg_a[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[4]),
        .Q(reg_a[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[5]),
        .Q(reg_a[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[6]),
        .Q(reg_a[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[7]),
        .Q(reg_a[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[8]),
        .Q(reg_a[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_a_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(a_IBUF[9]),
        .Q(reg_a[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[0]),
        .Q(reg_b[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[10]),
        .Q(reg_b[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[11]),
        .Q(reg_b[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[12] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[12]),
        .Q(reg_b[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[13] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[13]),
        .Q(reg_b[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[14] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[14]),
        .Q(reg_b[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[15] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[15]),
        .Q(reg_b[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[16] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[16]),
        .Q(reg_b[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[17] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[17]),
        .Q(reg_b[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[18] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[18]),
        .Q(reg_b[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[19] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[19]),
        .Q(reg_b[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[1]),
        .Q(reg_b[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[20] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[20]),
        .Q(reg_b[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[21] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[21]),
        .Q(reg_b[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[22] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[22]),
        .Q(reg_b[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[23] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[23]),
        .Q(reg_b[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[24] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[24]),
        .Q(reg_b[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[25] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[25]),
        .Q(reg_b[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[26] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[26]),
        .Q(reg_b[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[27] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[27]),
        .Q(reg_b[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[28] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[28]),
        .Q(reg_b[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[29] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[29]),
        .Q(reg_b[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[2]),
        .Q(reg_b[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[30] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[30]),
        .Q(reg_b[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[31] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[31]),
        .Q(reg_b[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[3]),
        .Q(reg_b[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[4]),
        .Q(reg_b[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[5]),
        .Q(reg_b[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[6]),
        .Q(reg_b[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[7]),
        .Q(reg_b[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[8]),
        .Q(reg_b[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_b_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(b_IBUF[9]),
        .Q(reg_b[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    reg_ci_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(ci_IBUF),
        .Q(reg_ci),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    reg_co_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(cout),
        .Q(co_OBUF),
        .R(1'b0));
  CARRY4 reg_co_reg_i_1
       (.CI(\reg_s_reg[31]_i_1_n_0 ),
        .CO({NLW_reg_co_reg_i_1_CO_UNCONNECTED[3:1],cout}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_reg_co_reg_i_1_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[11]_i_2 
       (.I0(reg_a[11]),
        .I1(reg_b[11]),
        .O(\reg_s[11]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[11]_i_3 
       (.I0(reg_a[10]),
        .I1(reg_b[10]),
        .O(\reg_s[11]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[11]_i_4 
       (.I0(reg_a[9]),
        .I1(reg_b[9]),
        .O(\reg_s[11]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[11]_i_5 
       (.I0(reg_a[8]),
        .I1(reg_b[8]),
        .O(\reg_s[11]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[15]_i_2 
       (.I0(reg_a[15]),
        .I1(reg_b[15]),
        .O(\reg_s[15]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[15]_i_3 
       (.I0(reg_a[14]),
        .I1(reg_b[14]),
        .O(\reg_s[15]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[15]_i_4 
       (.I0(reg_a[13]),
        .I1(reg_b[13]),
        .O(\reg_s[15]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[15]_i_5 
       (.I0(reg_a[12]),
        .I1(reg_b[12]),
        .O(\reg_s[15]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[19]_i_2 
       (.I0(reg_a[19]),
        .I1(reg_b[19]),
        .O(\reg_s[19]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[19]_i_3 
       (.I0(reg_a[18]),
        .I1(reg_b[18]),
        .O(\reg_s[19]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[19]_i_4 
       (.I0(reg_a[17]),
        .I1(reg_b[17]),
        .O(\reg_s[19]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[19]_i_5 
       (.I0(reg_a[16]),
        .I1(reg_b[16]),
        .O(\reg_s[19]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[23]_i_2 
       (.I0(reg_a[23]),
        .I1(reg_b[23]),
        .O(\reg_s[23]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[23]_i_3 
       (.I0(reg_a[22]),
        .I1(reg_b[22]),
        .O(\reg_s[23]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[23]_i_4 
       (.I0(reg_a[21]),
        .I1(reg_b[21]),
        .O(\reg_s[23]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[23]_i_5 
       (.I0(reg_a[20]),
        .I1(reg_b[20]),
        .O(\reg_s[23]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[27]_i_2 
       (.I0(reg_a[27]),
        .I1(reg_b[27]),
        .O(\reg_s[27]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[27]_i_3 
       (.I0(reg_a[26]),
        .I1(reg_b[26]),
        .O(\reg_s[27]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[27]_i_4 
       (.I0(reg_a[25]),
        .I1(reg_b[25]),
        .O(\reg_s[27]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[27]_i_5 
       (.I0(reg_a[24]),
        .I1(reg_b[24]),
        .O(\reg_s[27]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[31]_i_2 
       (.I0(reg_a[31]),
        .I1(reg_b[31]),
        .O(\reg_s[31]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[31]_i_3 
       (.I0(reg_a[30]),
        .I1(reg_b[30]),
        .O(\reg_s[31]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[31]_i_4 
       (.I0(reg_a[29]),
        .I1(reg_b[29]),
        .O(\reg_s[31]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[31]_i_5 
       (.I0(reg_a[28]),
        .I1(reg_b[28]),
        .O(\reg_s[31]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[3]_i_2 
       (.I0(reg_a[3]),
        .I1(reg_b[3]),
        .O(\reg_s[3]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[3]_i_3 
       (.I0(reg_a[2]),
        .I1(reg_b[2]),
        .O(\reg_s[3]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[3]_i_4 
       (.I0(reg_a[1]),
        .I1(reg_b[1]),
        .O(\reg_s[3]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[3]_i_5 
       (.I0(reg_a[0]),
        .I1(reg_ci),
        .O(\reg_s[3]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[7]_i_2 
       (.I0(reg_a[7]),
        .I1(reg_b[7]),
        .O(\reg_s[7]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[7]_i_3 
       (.I0(reg_a[6]),
        .I1(reg_b[6]),
        .O(\reg_s[7]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[7]_i_4 
       (.I0(reg_a[5]),
        .I1(reg_b[5]),
        .O(\reg_s[7]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \reg_s[7]_i_5 
       (.I0(reg_a[4]),
        .I1(reg_b[4]),
        .O(\reg_s[7]_i_5_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[3]_i_1_n_7 ),
        .Q(s_OBUF[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[11]_i_1_n_5 ),
        .Q(s_OBUF[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[11]_i_1_n_4 ),
        .Q(s_OBUF[11]),
        .R(1'b0));
  CARRY4 \reg_s_reg[11]_i_1 
       (.CI(\reg_s_reg[7]_i_1_n_0 ),
        .CO({\reg_s_reg[11]_i_1_n_0 ,\NLW_reg_s_reg[11]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(reg_a[11:8]),
        .O({\reg_s_reg[11]_i_1_n_4 ,\reg_s_reg[11]_i_1_n_5 ,\reg_s_reg[11]_i_1_n_6 ,\reg_s_reg[11]_i_1_n_7 }),
        .S({\reg_s[11]_i_2_n_0 ,\reg_s[11]_i_3_n_0 ,\reg_s[11]_i_4_n_0 ,\reg_s[11]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[12] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[15]_i_1_n_7 ),
        .Q(s_OBUF[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[13] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[15]_i_1_n_6 ),
        .Q(s_OBUF[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[14] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[15]_i_1_n_5 ),
        .Q(s_OBUF[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[15] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[15]_i_1_n_4 ),
        .Q(s_OBUF[15]),
        .R(1'b0));
  CARRY4 \reg_s_reg[15]_i_1 
       (.CI(\reg_s_reg[11]_i_1_n_0 ),
        .CO({\reg_s_reg[15]_i_1_n_0 ,\NLW_reg_s_reg[15]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(reg_a[15:12]),
        .O({\reg_s_reg[15]_i_1_n_4 ,\reg_s_reg[15]_i_1_n_5 ,\reg_s_reg[15]_i_1_n_6 ,\reg_s_reg[15]_i_1_n_7 }),
        .S({\reg_s[15]_i_2_n_0 ,\reg_s[15]_i_3_n_0 ,\reg_s[15]_i_4_n_0 ,\reg_s[15]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[16] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[19]_i_1_n_7 ),
        .Q(s_OBUF[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[17] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[19]_i_1_n_6 ),
        .Q(s_OBUF[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[18] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[19]_i_1_n_5 ),
        .Q(s_OBUF[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[19] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[19]_i_1_n_4 ),
        .Q(s_OBUF[19]),
        .R(1'b0));
  CARRY4 \reg_s_reg[19]_i_1 
       (.CI(\reg_s_reg[15]_i_1_n_0 ),
        .CO({\reg_s_reg[19]_i_1_n_0 ,\NLW_reg_s_reg[19]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(reg_a[19:16]),
        .O({\reg_s_reg[19]_i_1_n_4 ,\reg_s_reg[19]_i_1_n_5 ,\reg_s_reg[19]_i_1_n_6 ,\reg_s_reg[19]_i_1_n_7 }),
        .S({\reg_s[19]_i_2_n_0 ,\reg_s[19]_i_3_n_0 ,\reg_s[19]_i_4_n_0 ,\reg_s[19]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[3]_i_1_n_6 ),
        .Q(s_OBUF[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[20] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[23]_i_1_n_7 ),
        .Q(s_OBUF[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[21] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[23]_i_1_n_6 ),
        .Q(s_OBUF[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[22] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[23]_i_1_n_5 ),
        .Q(s_OBUF[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[23] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[23]_i_1_n_4 ),
        .Q(s_OBUF[23]),
        .R(1'b0));
  CARRY4 \reg_s_reg[23]_i_1 
       (.CI(\reg_s_reg[19]_i_1_n_0 ),
        .CO({\reg_s_reg[23]_i_1_n_0 ,\NLW_reg_s_reg[23]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(reg_a[23:20]),
        .O({\reg_s_reg[23]_i_1_n_4 ,\reg_s_reg[23]_i_1_n_5 ,\reg_s_reg[23]_i_1_n_6 ,\reg_s_reg[23]_i_1_n_7 }),
        .S({\reg_s[23]_i_2_n_0 ,\reg_s[23]_i_3_n_0 ,\reg_s[23]_i_4_n_0 ,\reg_s[23]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[24] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[27]_i_1_n_7 ),
        .Q(s_OBUF[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[25] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[27]_i_1_n_6 ),
        .Q(s_OBUF[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[26] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[27]_i_1_n_5 ),
        .Q(s_OBUF[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[27] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[27]_i_1_n_4 ),
        .Q(s_OBUF[27]),
        .R(1'b0));
  CARRY4 \reg_s_reg[27]_i_1 
       (.CI(\reg_s_reg[23]_i_1_n_0 ),
        .CO({\reg_s_reg[27]_i_1_n_0 ,\NLW_reg_s_reg[27]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(reg_a[27:24]),
        .O({\reg_s_reg[27]_i_1_n_4 ,\reg_s_reg[27]_i_1_n_5 ,\reg_s_reg[27]_i_1_n_6 ,\reg_s_reg[27]_i_1_n_7 }),
        .S({\reg_s[27]_i_2_n_0 ,\reg_s[27]_i_3_n_0 ,\reg_s[27]_i_4_n_0 ,\reg_s[27]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[28] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[31]_i_1_n_7 ),
        .Q(s_OBUF[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[29] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[31]_i_1_n_6 ),
        .Q(s_OBUF[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[3]_i_1_n_5 ),
        .Q(s_OBUF[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[30] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[31]_i_1_n_5 ),
        .Q(s_OBUF[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[31] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[31]_i_1_n_4 ),
        .Q(s_OBUF[31]),
        .R(1'b0));
  CARRY4 \reg_s_reg[31]_i_1 
       (.CI(\reg_s_reg[27]_i_1_n_0 ),
        .CO({\reg_s_reg[31]_i_1_n_0 ,\NLW_reg_s_reg[31]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(reg_a[31:28]),
        .O({\reg_s_reg[31]_i_1_n_4 ,\reg_s_reg[31]_i_1_n_5 ,\reg_s_reg[31]_i_1_n_6 ,\reg_s_reg[31]_i_1_n_7 }),
        .S({\reg_s[31]_i_2_n_0 ,\reg_s[31]_i_3_n_0 ,\reg_s[31]_i_4_n_0 ,\reg_s[31]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[3]_i_1_n_4 ),
        .Q(s_OBUF[3]),
        .R(1'b0));
  CARRY4 \reg_s_reg[3]_i_1 
       (.CI(1'b0),
        .CO({\reg_s_reg[3]_i_1_n_0 ,\NLW_reg_s_reg[3]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(reg_b[0]),
        .DI(reg_a[3:0]),
        .O({\reg_s_reg[3]_i_1_n_4 ,\reg_s_reg[3]_i_1_n_5 ,\reg_s_reg[3]_i_1_n_6 ,\reg_s_reg[3]_i_1_n_7 }),
        .S({\reg_s[3]_i_2_n_0 ,\reg_s[3]_i_3_n_0 ,\reg_s[3]_i_4_n_0 ,\reg_s[3]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[7]_i_1_n_7 ),
        .Q(s_OBUF[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[7]_i_1_n_6 ),
        .Q(s_OBUF[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[7]_i_1_n_5 ),
        .Q(s_OBUF[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[7]_i_1_n_4 ),
        .Q(s_OBUF[7]),
        .R(1'b0));
  CARRY4 \reg_s_reg[7]_i_1 
       (.CI(\reg_s_reg[3]_i_1_n_0 ),
        .CO({\reg_s_reg[7]_i_1_n_0 ,\NLW_reg_s_reg[7]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(reg_a[7:4]),
        .O({\reg_s_reg[7]_i_1_n_4 ,\reg_s_reg[7]_i_1_n_5 ,\reg_s_reg[7]_i_1_n_6 ,\reg_s_reg[7]_i_1_n_7 }),
        .S({\reg_s[7]_i_2_n_0 ,\reg_s[7]_i_3_n_0 ,\reg_s[7]_i_4_n_0 ,\reg_s[7]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[11]_i_1_n_7 ),
        .Q(s_OBUF[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_s_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\reg_s_reg[11]_i_1_n_6 ),
        .Q(s_OBUF[9]),
        .R(1'b0));
  OBUF \s_OBUF[0]_inst 
       (.I(s_OBUF[0]),
        .O(s[0]));
  OBUF \s_OBUF[10]_inst 
       (.I(s_OBUF[10]),
        .O(s[10]));
  OBUF \s_OBUF[11]_inst 
       (.I(s_OBUF[11]),
        .O(s[11]));
  OBUF \s_OBUF[12]_inst 
       (.I(s_OBUF[12]),
        .O(s[12]));
  OBUF \s_OBUF[13]_inst 
       (.I(s_OBUF[13]),
        .O(s[13]));
  OBUF \s_OBUF[14]_inst 
       (.I(s_OBUF[14]),
        .O(s[14]));
  OBUF \s_OBUF[15]_inst 
       (.I(s_OBUF[15]),
        .O(s[15]));
  OBUF \s_OBUF[16]_inst 
       (.I(s_OBUF[16]),
        .O(s[16]));
  OBUF \s_OBUF[17]_inst 
       (.I(s_OBUF[17]),
        .O(s[17]));
  OBUF \s_OBUF[18]_inst 
       (.I(s_OBUF[18]),
        .O(s[18]));
  OBUF \s_OBUF[19]_inst 
       (.I(s_OBUF[19]),
        .O(s[19]));
  OBUF \s_OBUF[1]_inst 
       (.I(s_OBUF[1]),
        .O(s[1]));
  OBUF \s_OBUF[20]_inst 
       (.I(s_OBUF[20]),
        .O(s[20]));
  OBUF \s_OBUF[21]_inst 
       (.I(s_OBUF[21]),
        .O(s[21]));
  OBUF \s_OBUF[22]_inst 
       (.I(s_OBUF[22]),
        .O(s[22]));
  OBUF \s_OBUF[23]_inst 
       (.I(s_OBUF[23]),
        .O(s[23]));
  OBUF \s_OBUF[24]_inst 
       (.I(s_OBUF[24]),
        .O(s[24]));
  OBUF \s_OBUF[25]_inst 
       (.I(s_OBUF[25]),
        .O(s[25]));
  OBUF \s_OBUF[26]_inst 
       (.I(s_OBUF[26]),
        .O(s[26]));
  OBUF \s_OBUF[27]_inst 
       (.I(s_OBUF[27]),
        .O(s[27]));
  OBUF \s_OBUF[28]_inst 
       (.I(s_OBUF[28]),
        .O(s[28]));
  OBUF \s_OBUF[29]_inst 
       (.I(s_OBUF[29]),
        .O(s[29]));
  OBUF \s_OBUF[2]_inst 
       (.I(s_OBUF[2]),
        .O(s[2]));
  OBUF \s_OBUF[30]_inst 
       (.I(s_OBUF[30]),
        .O(s[30]));
  OBUF \s_OBUF[31]_inst 
       (.I(s_OBUF[31]),
        .O(s[31]));
  OBUF \s_OBUF[3]_inst 
       (.I(s_OBUF[3]),
        .O(s[3]));
  OBUF \s_OBUF[4]_inst 
       (.I(s_OBUF[4]),
        .O(s[4]));
  OBUF \s_OBUF[5]_inst 
       (.I(s_OBUF[5]),
        .O(s[5]));
  OBUF \s_OBUF[6]_inst 
       (.I(s_OBUF[6]),
        .O(s[6]));
  OBUF \s_OBUF[7]_inst 
       (.I(s_OBUF[7]),
        .O(s[7]));
  OBUF \s_OBUF[8]_inst 
       (.I(s_OBUF[8]),
        .O(s[8]));
  OBUF \s_OBUF[9]_inst 
       (.I(s_OBUF[9]),
        .O(s[9]));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
