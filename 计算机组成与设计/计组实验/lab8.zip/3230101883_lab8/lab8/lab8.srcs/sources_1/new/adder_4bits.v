`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/29 18:36:05
// Design Name: 
// Module Name: adder_4bits
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns/10ps

module adder_4bits (
    input  [3:0] a, //����
    input  [3:0] b, //������
    input        ci, //��ʼ��λ����
    output [3:0] s, //��
    output       co //���ս�λ���
);
    
    // �����ź�G��P
    wire [3:0] g = a & b;
    wire [3:0] p = a ^ b;

    // �ڲ���λ�ź�
    wire c1 = g[0] | (p[0] & ci);
    wire c2 = g[1] | (p[1] & g[0]) | (p[1] & p[0] & ci);
    wire c3 = g[2] | (p[2] & g[1]) | (p[2] & p[1] & g[0]) | (p[2] & p[1] & p[0] & ci);
    wire c4 = g[3] | (p[3] & g[2]) | (p[3] & p[2] & g[1]) | (p[3] & p[2] & p[1] & g[0]) | (p[3] & p[2] & p[1] & p[0] & ci);

    // �ڲ���
    assign s[0] = p[0] ^ ci;
    assign s[1] = p[1] ^ c1;
    assign s[2] = p[2] ^ c2;
    assign s[3] = p[3] ^ c3;
    
    // �����λ
    assign co = c4;
endmodule
