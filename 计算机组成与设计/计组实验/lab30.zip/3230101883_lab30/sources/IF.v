`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:  zju
// Engineer: qmj
//////////////////////////////////////////////////////////////////////////////////
module IF(clk, reset, Branch,Jump, IFWrite, JumpAddr, Instruction_if, PC, IF_flush);
    input clk;
    input reset;
    input Branch;
    input Jump;
    input IFWrite;
    input [31:0] JumpAddr;
    output [31:0] Instruction_if;
    output [31:0] PC;
    output IF_flush;

    // PC�Ĵ���
    reg [31:0] PC_in, PC_out;
    wire PCSource;
    assign PCSource = Jump || Branch;
    assign IF_flush = PCSource;
    // ����PC_in��ֵ
    always @(*) begin
        if (PCSource) begin
            PC_in = JumpAddr;
        end else begin
            PC_in = PC + 32'h00000004;
        end
    end
    // ��ʱ��������ʱ����
    always @(posedge clk) begin
        if (reset) begin
            PC_out <= 32'b0; // ��λʱ��PCֵ����Ϊ0
        end else if (IFWrite) begin
            PC_out <= PC_in; // ʹ���ź���Чʱ����PCֵ
        end else begin
            PC_out <= PC_out; // ʹ���ź���Чʱ����PCֵ����
        end
    end
    assign PC = PC_out;
    //InstructionROM
    InstructionROM InstructionROM_ints(
        .addr(PC[7:2]),
        .dout(Instruction_if)
    );


endmodule
