`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/30 20:05:48
// Design Name: 
// Module Name: adder_32bits
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



// ģ��1: 4λ��ǰ��λ�ӷ���
module cla_4bit(
    input      [3:0] a,    
    input      [3:0] b,    
    input      cin,       
    output     [3:0] s,  
    output     cout        
);

    wire [3:0] g; 
    wire [3:0] p; 
    wire [4:0] c; 

    assign g = a & b;
    assign p = a ^ b;

    assign c[0] = cin;

    assign c[1] = g[0] | (p[0] & c[0]);
    assign c[2] = g[1] | (p[1] & g[0]) | (p[1] & p[0] & c[0]);
    assign c[3] = g[2] | (p[2] & g[1]) | (p[2] & p[1] & g[0]) | (p[2] & p[1] & p[0] & c[0]);
    
    assign cout = g[3] | (p[3] & g[2]) | (p[3] & p[2] & g[1]) | (p[3] & p[2] & p[1] & g[0]) | (p[3] & p[2] & p[1] & p[0] & c[0]);

    assign s = p ^ c[3:0];

endmodule


// ģ��2: 32λ��λѡ��ӷ��� (����ģ��)
module adder_32bits(
    input      [31:0] a,    // 32λ����a
    input      [31:0] b,    // 32λ����b
    input      ci,         // �����λ
    output     [31:0] s,    // 32λ��
    output     co          // �����λ
);

    // �����λΪ0ʱ�ĺ����λ
    wire [3:0] s1_0, s2_0, s3_0, s4_0, s5_0, s6_0, s7_0;
    wire       c1_0, c2_0, c3_0, c4_0, c5_0, c6_0, c7_0;

    // �����λΪ1ʱ�ĺ����λ
    wire [3:0] s1_1, s2_1, s3_1, s4_1, s5_1, s6_1, s7_1;
    wire       c1_1, c2_1, c3_1, c4_1, c5_1, c6_1, c7_1;
    
    // ÿһ���ʵ�ʽ�λ
    wire       c0, c1, c2, c3, c4, c5, c6;

    // --- Block 0 [bits 3:0] ---
    // ��һ��ֱ�Ӽ��㣬����ѡ��
    cla_4bit block0(
        .a    (a[3:0]), 
        .b    (b[3:0]), 
        .cin  (ci), 
        .s    (s[3:0]), 
        .cout (c0)
    );

    //��8�����
    // --- Block 1 [bits 7:4] ---
    cla_4bit block1_0(.a(a[7:4]),   .b(b[7:4]),   .cin(1'b0), .s(s1_0), .cout(c1_0));
    cla_4bit block1_1(.a(a[7:4]),   .b(b[7:4]),   .cin(1'b1), .s(s1_1), .cout(c1_1));
    assign s[7:4]   = c0 ? s1_1 : s1_0;
    assign c1       = c0 ? c1_1 : c1_0;

    // --- Block 2 [bits 11:8] ---
    cla_4bit block2_0(.a(a[11:8]),  .b(b[11:8]),  .cin(1'b0), .s(s2_0), .cout(c2_0));
    cla_4bit block2_1(.a(a[11:8]),  .b(b[11:8]),  .cin(1'b1), .s(s2_1), .cout(c2_1));
    assign s[11:8]  = c1 ? s2_1 : s2_0;
    assign c2       = c1 ? c2_1 : c2_0;

    // --- Block 3 [bits 15:12] ---
    cla_4bit block3_0(.a(a[15:12]), .b(b[15:12]), .cin(1'b0), .s(s3_0), .cout(c3_0));
    cla_4bit block3_1(.a(a[15:12]), .b(b[15:12]), .cin(1'b1), .s(s3_1), .cout(c3_1));
    assign s[15:12] = c2 ? s3_1 : s3_0;
    assign c3       = c2 ? c3_1 : c3_0;

    // --- Block 4 [bits 19:16] ---
    cla_4bit block4_0(.a(a[19:16]), .b(b[19:16]), .cin(1'b0), .s(s4_0), .cout(c4_0));
    cla_4bit block4_1(.a(a[19:16]), .b(b[19:16]), .cin(1'b1), .s(s4_1), .cout(c4_1));
    assign s[19:16] = c3 ? s4_1 : s4_0;
    assign c4       = c3 ? c4_1 : c4_0;

    // --- Block 5 [bits 23:20] ---
    cla_4bit block5_0(.a(a[23:20]), .b(b[23:20]), .cin(1'b0), .s(s5_0), .cout(c5_0));
    cla_4bit block5_1(.a(a[23:20]), .b(b[23:20]), .cin(1'b1), .s(s5_1), .cout(c5_1));
    assign s[23:20] = c4 ? s5_1 : s5_0;
    assign c5       = c4 ? c5_1 : c5_0;

    // --- Block 6 [bits 27:24] ---
    cla_4bit block6_0(.a(a[27:24]), .b(b[27:24]), .cin(1'b0), .s(s6_0), .cout(c6_0));
    cla_4bit block6_1(.a(a[27:24]), .b(b[27:24]), .cin(1'b1), .s(s6_1), .cout(c6_1));
    assign s[27:24] = c5 ? s6_1 : s6_0;
    assign c6       = c5 ? c6_1 : c6_0;

    // --- Block 7 [bits 31:28] ---
    cla_4bit block7_0(.a(a[31:28]), .b(b[31:28]), .cin(1'b0), .s(s7_0), .cout(c7_0));
    cla_4bit block7_1(.a(a[31:28]), .b(b[31:28]), .cin(1'b1), .s(s7_1), .cout(c7_1));
    assign s[31:28] = c6 ? s7_1 : s7_0;
    assign co       = c6 ? c7_1 : c7_0; // ���յ������λ

endmodule