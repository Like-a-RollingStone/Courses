// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
// Date        : Thu Nov 27 14:23:17 2025
// Host        : DESKTOP-3MS8VAT running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ DisplayROM_sim_netlist.v
// Design      : DisplayROM
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a200tfbg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "DisplayROM,dist_mem_gen_v8_0_13,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_13,Vivado 2022.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (a,
    clk,
    qspo);
  input [7:0]a;
  input clk;
  output [7:0]qspo;

  wire [7:0]a;
  wire clk;
  wire [7:0]qspo;
  wire [7:0]NLW_U0_dpo_UNCONNECTED;
  wire [7:0]NLW_U0_qdpo_UNCONNECTED;
  wire [7:0]NLW_U0_spo_UNCONNECTED;

  (* C_FAMILY = "artix7" *) 
  (* C_HAS_D = "0" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_I_CE = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "0" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_PIPELINE_STAGES = "0" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_QUALIFY_WE = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "8" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "256" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_clk = "1" *) 
  (* c_has_qspo = "1" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "0" *) 
  (* c_mem_init_file = "DisplayROM.mif" *) 
  (* c_parser_type = "1" *) 
  (* c_read_mif = "1" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "8" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_dist_mem_gen_v8_0_13 U0
       (.a(a),
        .clk(clk),
        .d({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .dpo(NLW_U0_dpo_UNCONNECTED[7:0]),
        .dpra({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .i_ce(1'b1),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[7:0]),
        .qdpo_ce(1'b1),
        .qdpo_clk(1'b0),
        .qdpo_rst(1'b0),
        .qdpo_srst(1'b0),
        .qspo(qspo),
        .qspo_ce(1'b1),
        .qspo_rst(1'b0),
        .qspo_srst(1'b0),
        .spo(NLW_U0_spo_UNCONNECTED[7:0]),
        .we(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2022.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
M9ERyrMNmk2Jjyg6ZCGYQpTqx5C+74+ICn/vAQ5KoRuxJNbql8tHJjFcOe3FAJX14Nokq4wtfvZP
2sPXAs/eYYzjjbnt4nx8oZRRPy0XyDpvba/qxyqBSxjChIoPMDwpXnxi+chZJU5N1zCNt9FZPAep
nLCjMCkQTlKbP3cUJIY=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
FBAg02qOh8M8uZkNvwWHoY3ELncwvHjjgL2y2qLN7xuxxaPQj3LdyD/IETTPdSjNCB/rhpJxbT1y
U5fbF28Hkp+bzDuxeTWPX251wMhiEmdm4jhyMl2z+GRf2Z6VJ4bVM5bieaJvsbjuyQ9Az6TDmueI
14citDEbyRCyJD9EiVckdS2mZcTl37oVFebKnIeJGmNjOc2XrcM84JVJIG5iv3ryS2hAG9/84hEr
u3DYC+xS2w5swJXVSf0zV+w8xZulS3PTPLELIM8O+SEFdHetZKnrgG1aJ7V5xu0RniGAsyVwVbgu
M1jPqNLyU+9kyETKfG9jcGEIM2I2gUfmOvRs+g==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
TYvdYOtu2OcY/hp0LCFlgwGgJeLJ5MSBDPjuyI3760LiXtklDVs7CUFlvRRXMgAzbHlMXbiHp/Xl
cvmN035ayt8D8gPWRXxnbQf3kRlW6EIFwFMZ1inL9b5f47gsuvCP6MaKiTg0W7+/ZeHbM4jHXvRe
b8HXvQvK5kVwtayEwt0=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GkcGg32vdV7ZS9x4Uw9v3hZEcxD5hMmQXUqa6shDPbzqUGIxrKpTOb9W4Sgi8rq+qw7QpAZp2JW/
MkYAH1WikFlf+XWG57y55EFV7oRoKQDh2Yz0sZEwVhwTGwSAqfnjrmPITofdG5eiey1ySGprEKsT
mqWAV+ZN7TkQkKup0Ukf1O+8giYKT/7UibTRqG/CT9dgU/4atPgYh2QjNMVrsAH/uzDxh7stQMYe
nkjZBkpLWOq7mxEXTKVtYAD/8G5qCJELRcvCuUKYz4Une1wDj+L/vwRK3IAdWKQ+/5mvj0q5XEm7
IKu5HYvalbySwRWzaB00uobXZorNhfwSv45jHg==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
JnT3Bfv/DUBx2mIm4+jpmHjzhKoX4mNpcc/lgscv3iYrJw8Uble396hMwPsVZ+kkAsmYtegNCiTG
Z7kqnoNeWHv+Grdizsq0QM9S2KJ5EoZhjelE+3Cii/ztNHf7Y3c0nBPnioUQ5YmWk7vgoQl3SJ3d
vwD3G0c+fGJBRpi14hTJOB2wtu4EeWcJ1f+01LjKINeucLlwacjnN0tElyRgCNKfsRDAQiMqwKqg
XCleeNY0cyLXGI30pXMpnbLizYlNKgVD6DSeNaby0dhW4phR0a+9xteo8l8eRVzTO+VSOcYSy8rU
6Uj2y0Up19vcq91C+/YeHlh24VwNI2TJeUEDwQ==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2021_07", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
AWr8D+IaT/X0jMJSrwmWnhWOjt0+8oyULINYaH7QGBLgqKCVtf8rqo68R3/TZ8gTkN73fZOx0QCU
3WEp7Ga1gUsqEgy+2zGlncYhOzx62FJm4Pm7S6LbE1qdg3/9Pp55JLaf1ouYlZccQJ+yawj0HgL4
zR0T347Zg2aIFxQZ28icCuJbxAZsZgAT30scXsTMMvXlQQ9NI21OjirKgHRn3dldIjpkL+BrVBkQ
Q7MMiTBhpCn/c+WXk4H9BPc3vMrVoh6r5oo+e1858Hk7osyxNI9zuACaGwdAatsW756kQBMsQoUj
TmJksSfucjrHVSuLFffpztOARH3LXrhZcCZdoQ==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
fPVwMHnHe1L8weZTnbBxjlAabwZZnO4DZSHaO7tHGHAw6U+w+7Rc3BwfQXtiTyGXP15rvoLhvVpo
i1Tzs4zrV1X8vlWrxhS6XA2VO4RFkpCjmnHpvdgnW9mpk7w90QOEZIWZQST/o15t0wDT/kv4J36r
Ho59mVFCGQQSSYx0209u6sG2rNpJ5HtWMM+tDEDHUArucrBmPOoZSq0VSQsTHtjJQxr3U5fv9l6q
aEBWkjnLJ6zqLkt12B3q7V3iFORPpz6XNMqA6wzArzWirzgTCw3CduiSAgbNgoGmV4eNrVb2DfOT
5V4ni19GigMG1fHCD9dNPWGiRCWpY6iiN6iE1w==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
NkQB16Pku9sdGFuAkY+DjFhWzKYvb26AsK/VO1//MS5ztnK+V9d/0K8nVee9kGDNC4zorSd1NjRc
Jkj/JJm1k/9QiQQwOSB/94zKWUyVH2Rvw3UOuaTu9pWRQsIdmPNwXBKCOF5L17HHGaNqYzvHF7YY
REIp6VR4HcyLq2beYXn09Mq0f84obUr7+CMgh8i1SaLa/ydMPS9xsm1i0NFB3qcEC0dDq6xklwsX
s198UBI5mBJTEUKi38eytWXzQPFTmqdlD3Qn4CgstxSdoLrFHchISqt+L62U4xU6aVyYXmVaeebF
I1F3MAXQZwZwGETW7RW9t/+3pJtkjPfPtdnqu/Sg+zP+vLjSV/NcONctKnTj86/z+TTehoSH8ccr
BsjV0PhAtR3+RTr3VGkKJoUNeE8yFQIHlES8UamuSNMh5XrbmcbFx22MZ9gLOa350ytm1N124jNF
V860l5gGbt/8NcGf8I3EVPrYblJ5ZLGsZkVg1cKBMUys1yMm6Ci2Mruc

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
JDELzo7luYHcwIl8sAAMR3hvm1tr+ZaD3VKTvYj1uwYFwuIPCkUfjVi8OMAgp3Hh/R1wDZSeoY7T
xpO0sKF9MsovKwwArnByLL8zZflfJIe5AmC+jE5a8qUxydp4liMdOypRTLu6U6EUYUwSj6VOR0Uj
deCoQCr/gVZ2GdNKF5sKZsGXZSvx1Wag70BiGs69qhgUvVVlpbqpNRSB0DR/2IuSKCHhkucLXiTk
zVS7zC7GiyNYE6l/Yu5Ov25Cl+lY5cMZkqKvIFm90UiTBNYk4No5ofXnH/E0rNcbydv0BvWDmgKt
NXVratbi0ztKLb27z2lw5ZZzXCihB41kx4VjqA==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 14880)
`pragma protect data_block
f2yM3JLhDA++sTcJVhMu2nfg20WjRUil1DXFaQLWoFgN1x4P7qXIcxlHHm3qYEcIN73b4Lh0gLfG
yzIUhbcXbNRPkSDNqnEVHI4nhsTllrKTjzwxhT+y1QHX0BIlta0h+v8VFBBx9jpJ+nhjK3fvWrH3
kqr4A7AiUyIpmfBxAxFDuudK/FQ1wQ/s890F73V/y8kJs/pjBlEaZq9lFd5K3cNwi/9BBTGLfB8k
Ohjv/pW8T9Cz5n+uEE01yMIzT6/udtBZg+YCCk26cwPwGFVMBeHKlh+jUOJa7A/T3QPxGSr3p1fK
RSvHverD08Tw2Z61TUZqh4MxpfXwN0IsY+JiiR5D42bTwXU/g085Nq1etoxAwTSAO7I0QPoRRfXn
ZVMjRy6Z9+vqby+1jylG8V8tJtMXSSHS0b2OhVNIsQ09S2kQRA3DkAVvQ0YRtk3M+9ASxe16YuCc
NIJMm47f3bIIMN5e9qhAOB2IlIUBkzxR+KjxdOD8NBo4/lfwSERe61PWgmmeJL5VOyrWz4rsbB23
JV6Z0FQCMD8jMF+pMJmm9BfMj+sqcHusZYrXQ1/zo8+28cKrKEvVWvYbRtLGtiRfdz5WsTx2gcSm
kuRdTsbuB8rKyqSEmUcgZIvxf4fibv+7rke0OrU1WMnwSEdNo/kpm9noouVBLg+oYZLof2HoBBAq
s0rO6MeMrSt3gSg3G4qkRX7ugZKmnWa7J0l5+s+87Jttr2acNwHSHZgISGGQf0vdYDQP9kj8oe0C
pvkDLA94btlp4icymz/akVWXyl/w2kvv1JNTZIueD0LVHA5Lr2Lgdb5dN34nAtXANKQ/44Dp8jdt
XT46VevXJbD4cqbzLdZuHTRR3gDqRITC0FH4zEU+COsdb1HAwiROBFBYF6tpFC/5GCtyPC6bzdLP
btwrab1obWf0eA7nYoUJwAotM9gu4a8pl7vJotYpt56sxxvoXPPYxSd4ldjYyH/Vl9GBMlgywgfn
dyc7A94MOvdqsg3Dq1Vg1TGPqifb6Awwrny1aGh0C6GIKVxnc7F5X8O71oYOczG4hyC5ZXkIGo+B
SmvseQd19l/7Nf2u/n2oexdOCKh8d0xKoshNyshpd3wqy+cHlP/F7GHcwSLsFbMOBAAyvJ9rbrXB
q9KY6nlf0dzcOjv/oOscyKw3j9dgnGiFM31cXiA8tMku9gXtxdKdlA99Wj75Qf6+SKJLeV066Bha
jN0/NaM+hVn6wCxbBT9JeNwHDzkOXmPH5wCquxm1gO7tSdyMKLPKAHw7d933HIEXBZ7UGyz5fT5d
aytYLeEf93VfDRBYLFHrSjJJnlp7lFwB6NIrO1pPkG+qhfitLqN8M1PtD+t38bXIUgD0Geb/h4I5
k0hddB7vwqEEG1qw9tAOYAQ5TQ3tvPXBxkPKjTxYAXWOnYgGmY9K8TU75TVpSRzncg6j/0X3np2U
HZWr+VrL0OsJl/KXvnewfLyKnZT+VGSQc83WpJrZLKvTlcPpB+B+DTt9CFM14KicIaeNtDD7Sj29
q81Qa9xLx6ASl8t8w/iQRxFDV8yhqEiFHXpkjBtz/z4L9HSH3+FvA2CKTtAiQtvURgVeViAbWDK+
rWsiaGQdIau1sR3Rlv6TDmCso3WllsavULcQC/oiWwaLh8IbKme/2IFZNIJTE3BSetp6V1OdUNj8
qLlzDHGm01RDMby2HpnA5wuGUJSx6aA0AQQ5FoM5zZEGuycvk6ci0uNzcMzXMpQiOW6+9lcO0Gll
wVyMGZM3tuxcFseL9k4vNXS8AtpkbJZbyg5uchQsGOL/NAjPTZbhJXO4CFNl79GKRcqTOFHTtVUi
a0LZtQeFPwjlH+TKmSY3jbWRCq/nNuCoSZP91b8V9Nm1+z8TnFmV/x460gMbL2j5juwWOJQKf/Rc
rSmxQGNUr8PAIhI8oj6+mXPW0Dqd+S7E8wfZO5zOhEsDkCgqI/3+8Qiw4yuxu2KsdK6aXsEo7IbN
1kjJmbC4TTQudFB8DXjD4LmI+GtDU8MxuU+ZF39POrjMNxVR8NLwzPG0l0mE2VZR8XlRDpjszOGd
xMdX3ixsWLQwcrbSjDIkqgbtaIPm2o4My0iEGSjxsHQ3IzRBkqOTDkg3a65w0m3Qg6gjXQfGVG2B
QDdlju/Kw0ztlr0XUV9ErwkIIePmL4eEH0GY6NjPEBDHDuxCLiu+eivjxXucgius/h37CkL202W3
QlV9+6j+bm3W/N9BwuczbZLIxyXORgyb+1nT6+H7Bqk3C6BcXqVsf74xpQNl6gnmWTopOoqNmfp1
am7liFs85NnTszYd3WQ2WQZYNPifPsNmSf6B4b5Nam3L3Q8JERvjMZG7L4EllryaIQ16z7mKp0Xi
4mnVmJlxhSRxfezd+q6oZlEXM1xW9qn0xxy5CaNsMBDs41OLTwMohb4fCzz3IIRvpMKwbhoyh6Yd
hF2cg3aEiX8YvwKY6EoWG/zergZKWqhcsLxwQrHQrJHvIb12A5M2rbU1SbmENilzS3Pt6ZoxfXLD
HNu0hNC7lnT5Zsw11116YgaSd4SUB1E3tYhhwJcanfeQMlPDA+Wl/Ok7rAVis1gjJwCfba9EAG1f
Fp3wM/WQoADNV21GpoSgEGq+UPPb38tb/dJTn7wX+jhP1P+bVdLTQ80M99nLU6OnwnWbQamNzJHJ
xTvT8l9emgS84N18mDy5ur2WfpUC3arPMOzGxO3woeY0RA8nl8PRva//a+SNM2ppAOm86Bs4rGap
dX9sLF9EQ93nPN8eCtPhN3aqBsY6ZFvy7qvGKfOcnMHBT5mC4yvnGFbp57a+Ok2qBc4H1qLlwGW1
TJPwNeaM9dfOgRVgoF0damBfuES4h6yEnEnW0/l4f6Lb0DQ8IT6pxc+APXGDLVdgZE4AFlDgEJk6
ufKNc06e8e5KZ0HWYZN/TOsj/YK6wbPZCQqRM3WZ+jig/GjqYDlQDIDJBZT7L+OqIWSRYJqS+Lf3
HhbJXv5rGQeRK5sLOkXHXOx1I9/RZc2lsqAZN2qYsG/sVGk/3WjLtNaix2j3KyKeLFqjadFYh9B/
GA/mzySIZOJnf3nzPAVs8VfgxaLC6Evdjh1YHGahLxYw+pu2NlvOpGRrlWIdOR2/pIt8//SYBioL
oQeBqxKvgYXZ6zpN6F3oChoFM59AWgv9HW3/b1gfw37V0uqXjNapwfw586nIvLmASl/XdgSaZYHH
uH9dG8FinILry5vGeTAbJT8wt4+SXFrx9iosF41WcAJjFYddMb7rku9q7H7+2hMOS6YU1n+Ge7ja
HP7WLVroGW1cAAzAZxb/umD2fRBFrmLm+F2I5nc/enl+0CPijkdqTKty7hRNsl0HJ/WqIbBihJz4
HUEWQWKVm5stndLE57hq32zTpjE/TUsL7vUZey9Z8GQUi4cP+RAPJqDcTP2fr/4PytJnzJanRbLI
3nPDEPBpA3+8czhe12d/UHDSJXDjcjYB9kvox1NFdEua/bmx3/acbeYVP4xIMfO/0erksvEU/Xli
b1tgnTXAq3Eddaae37o/EECOllaRGpQhicub7u64V4a8b4sUdFXXDyGCWRIc4bOfLNW8Fpwktbw7
qmkHeNhxhQKSqHwjH1r5PBZok+EAydRErv+8nNP2CfPg79RlNujz89s/9bRXLscn59MwbierzYw9
QbSDsbt0iW6ar2LZzzKm3ZGdvyeJzdCnCS5l/CiWxhFduNkqh9XmbhFBlq+cEJN/l83KfirBJsxY
Nz6C1kKBunEsq9iVRPSk/nBX4AERJ2UUtK3AHI1pCa09w+1NGnb+d8Im6IGaC1IjWhgjqK/wdkr3
Zd5akWYlnLpKyRjd5TUFYqHgV0/ntJVDW7K6wzXxNjRoGomeq+Ijiw8bYc9fbra8e8c8Z6X6QPyG
3LcsgONQ//k9jKEIARyn7O2Mvj5xrqvSFLY2IunvjY4rWL5+STHNIkY2da9ivmaR7H663fMt8bUQ
Ap4MxkhCQglfqm8uyacPRpdzYOGMjwZ9l/f+enObDOOg0Boy8evgvhB4Rl5BFbE5t3z97WDvxJ8G
dHLB52RudEQso0wbgfyC1RhIotGsFwrPJ+lof5rEEKuSgt0iYYEvClu8mjtLsHKu5o+b/vRa61rp
1uGzqs3cmtdMjsJhCdnbMMR1sKnLZVnNM3PCaoWAM07ruTXjM6+OrnCjU00GwelS7z4xyyWQdmEO
UO2pEQdOzBQ1Rx5oU8xktKjghza+ipplpszJQYoumUeLWrf9bsEHlwSBA00XC5v2vQSSb3OSnK5B
pI/sTIulks+vUGxw+ScUxN62Der4PUvPECNM3m0uWMILAzlzBZ7Ma0oABgh7hQpzsYbEiOf8BSTN
V85VTupiuRbc/uI8OqDv1iS/HxONmOvuj7S/zL3D2aYbj/fCxXlEv19kQFc6lf8OmZXxujEnu/8F
I2zPDm9gwkCeNlempB5x1/IXqDtj02Ovb3ZLQBhZ4Yd1kGOo8KymvtAzjiPIskm6kT5eECmBa8Jt
Iv7w46VVabTbNSzCBFpHjuu8c1Eu44/M1X6uIN19VHUZs1tEHLYVZRdMQXCSSN5e8gGxwCz93Uds
VRFcdoqU93xMCOSm9xotlfT8x69LKWIMcqv7ExyXpbJoTNk2dLTgRjxJ+F/ZbLK/SDUoFQGWO+VL
s4MDJxyWCiLm1ZFhLivQoslwadeFo7QtpVCRVDjypAHw6JbFq+gcm2vZZxMCnldLTATK6B9jxhqb
LH347jgakL3CP5HYfvLZD0h6rpWSuxPirfR2VJJrescXVXXHOfqgk4uJF+voyywazhcyRMV/c9Rq
XZxGTxFRHGFnNcW9KngN3o7+PtBG1gTxJPmziSBnFsNR1mMvt7npLKqzlQoZUG23XCQ0SpQymcfx
evosyHvEGpuSOebkxalTuH6S6uXtnMkr+ZGg1w1jTx3KhZIuu5P8kfyIDJm92iNQ8TOdLr4e2x8K
mmExwJ+Jd4pf0iZvmOPp0hAc9nvQbZ5p9M3Aa75zAuONWrAm8xtzVdXir9x9NbhvWZL+t1MLheyO
ABynMFops1k+SanHwnoQhyeiEKM2hsxZ9kwL3PZziphdrHcH7p3ypgnLIIzW1rErHGi5R6631vd0
vh/vNYPPnq+2nCLYvmx9y+ZYO23vAs1KlFn1T+8aYFS4Irxb2m5pPz/OWiICqrrrnQAeu/GJL2QB
D3Ln2JhsS/bMeqlcr1KOg57k5+zNc5xPurvx9ONjWvQeaFLRM3PukilEDanNyHUJ/GXnyGn5zxiZ
3XrVXqX75xy94PkG0vTQEIEIGkn0XLDb740Mc/X5F3gZKQI/P3fr3s0YRbCRYXp0rz6RWOk8s3r5
y4BIK8oPLi45wD7Zsaj6IkSQbz4IPRsSY53ZhJLTFcq9MRL2gS53TsN2k0dswuhEA+IGB7TdCEFv
znIeq2+d3OMK5jBRA7sRR9uhtw2mUg6xKdspFbVUh3wLJ/ffEtXELigMcoOzX3xZqJ69xDeMUoOb
5m0uQiA1W85MkLJqzlYM7GSdzgKB0e7n9FrDz78nSJe0CFmUu692sjY7vJ9D+1N3VwHn9hB61V3R
u8UPHEblzU8a/TolMhbuAyahuOh4b7F+yG68GjgFqcgqbqTF1BNu61RwIei1+1GAib1QPb/BHnhi
sEX96AHbgLEk8T3pF6oONt5v7hkd24pAMaEiOwUSFqbCa4aZN2kHLEyt0HJKLbNsuoiTYVg4RiOd
pbqlVdwEMqOcJyY/+jjg0+nE4u3F29cOONdyBBE0LhzqOhT5soZuPW+Cm+j8glAdUBD0yBaQISLg
KJ8FkNZBjrOOkLqdCgSdnzpO8f4k/ZNzW6ZgIiJ6wNgE1t0I4TrDL4QfdhxFUTRp8ysKojKSquTa
fVqoxMsJ+8kzYZzD7egOEAujFlYSR8wPdpHXBfS0HOJovNpKrLRCtOFsM/lUVvXj7hwwPv97RuN0
jg4FK4BtwewIknEFMFIywIBDSuZl5i5Ju+Eiw0S6WXDdHaX356oHYkBYz0BvDm9ROpkQhNR/r1Ng
fiB8U6wgO2RrVPv7/Z5BTnFW3LqMa+DyFU0Zn3yWMIU8plWncl7hn4lZ+Ry1FILxZ4lfuFTIB16E
4sbrVd4cyqCU29TQ696Gq/oDfGtAe75FI++IRfQVxXQsiuxxnmJULo97bKT2D4TRFlAMdABNFcMc
zyQZIZ2RUJsQG3N6pw3MVQnucVJT59qnvyi9hlFfX3f4GBVf4c5/KWt8obszzx8pJoDt0BPhKBMN
RmczXsFPT7U+1N5N7eCWDTUeB17ZAYikSL3r8Yxx6JSYW6iQqQN0wOguaHxTjfGdAzuSYjjoEn0q
XO0lbN3wLsrNlEyqj42yxugedNiuEiZVIxAIR+vQ1DuMF7NdMrRoh1Zwp1BeGUiBVi5Pa4pB+iZF
jDsZ8LcVutl/HrxUXFDdyK4IEPYbMmb9x88k02gNHeSTgeEi/H+PTSr/oj9GACydYkH43Fp+eMkc
x7lEtN2sFdSL5yGEpiAPPCqhfYoLyJ1gJJ6EqFfpYQRkeHnQELg5zP2bbF9l48CMZtBwT0GEpzZT
XV+3fxrbr1325ZvISLOSvmtvwdxrHAOmLJFtiqE8ynL8HuBzPfAwJw0vl5I6HNPFt/3YPuo52zw0
7/5vsxB1wMZKcAZ//sl3JxwJKuOrL8hD/Yp5cBTzgJ/mN0Re9/I54i2ifIa/oOL+d1GsfxBsGLGI
s3g0gNFdQ9vPWlCzOtmSp/9sF37z51LBRcQSlXDnjeN8SbWdw2qtcFwT5CKTVpfWjFqlll27gov9
Dnzz+TTviv2W2nq+Sh4IyqL2zYiPplncFVV7lKtM9SBDW32Udnd5zdfGv1QQXhFtAaiAqBVNcnWJ
Gamyz60EDDfn5+3vtak6vSxd4MEyOY9cuHVphOfnXOFIxu21tLSR7fpR8LRufz2wy7uze0EgZeUk
uf1zU3sE1vj8hEzlXsO1N+l21f9cqnsoiHeDSwgfpl3cKOvr5IvGTb8q8zLpgmbDRIfR7Un1L12d
GE0szlDbh/JXK9Nr+YI0OUn5+pqjqowCWSAT/0nFyraTYig9IIK7O7y7q9WLsVIvV79jWDrPFr0i
hIAXaYnyYVK0oBYV5lQa6QVH6uYx0pJUKviZjyWw8grRBY/uegYpkj5VRfcMbEVkNZATafd9Gr8Y
pIchB8+0mClS/YcBPHRF5fjllB0rd5F8l8yQTIm54tMmp9rn9fA67NwASogU4QdRjkKlVb7H5qgF
orhaffxOGOwiXU6yDQHUcY42qCK1K5UV0er61swVMPnY3AmjnMoiMB3QFyRVQeM9YERr6WU+qWTG
Gn+NAk7rCs5bfi1c3Jen6fhkuH864R3byMaWC8Jw3alLsWvzQ5P3/RZu4IziFdVMflV/mfF2iiyF
vb8xsmjkK7zHJSmht9bw1TZmfIu1v6y2z2c7Icz4pQZqnsLpIyxnSj6NYPGviguKDrSKE76ipeff
aWhwIeDaB5IEKiOrKfzYIfLsVdEX5fzw6n72WxDjFin/FEwpPXM65b9MnDU3sorTJNammr1Qy7oo
7ETB6jzgQ4L8lOJLSiZQnjt2AShmnlRgLPoR9fnrc8KMTh05BG3/hhP64qm8kUXOaa8VPdXBG5li
sUMR4uHLgR5DA0LABmJWtOzdIjj1MNz3XiUafyzdq1MOyHyR/gUqpnaj3XZ68eeXKUdzVwCU54lz
3/DP069PKk4eCQZEZ6qqDR7ATwSPptqB9zFOgitfBUEpH4dXK6IETdOvqbCurawHmHCKxPfct3Go
auYDAXHJiXa2TW75szPXZ8cAB1gfF+M2yeVM2i798R2L5+TvTbAhfzbqg2K5wUP2HwTyfJ3CkC7N
POXItQBLV13flX+KcdM80zuToSdgs6YSU4FChBp/eVD2lnO3rvdwRULW0lql7/kpVokDi68DK/80
fT4Y5nIW/+hwRMTMVMhh8Ea7yCoRvPLBeRboYTwRGKQe3NBFgJ+g84QHyp4igFmtyyj7V0hCO62t
kHiLdcEq3G8HKTUxnlX6jtjhgvC/W5MiysfAG9GPAo0eN35uE8kE3nYtgWkhDUTVHIeA+s6aT6Lx
VI46mHrwZCBhvUBtNdE+FBSGW0VweoJWlilimW96sAKDBxoeL6ZtaOZi4nRqLx7NQZHJYfYj3C++
Y+6mpdk0D5VMt6IYhW7uMLwo6Fco7jWGqwr0rF3/HgPq8uI4V5/PStI+HuKgTQCVW4VpGQftg9lZ
6r9+a9qk7XwZxLQq360mibF6ROxGfCdbO1gjbITnfs1AFs0KjC4gPZ/AQKJnTZcAi9++7rMeR+nH
huo1yLbqv5M1pjOJK8FNZtrpHrAo18wmiooFsqePiM0Z6n7maNqJOjip6ggjAf/ye4SKGLivLI1i
4CykQ39zJ8SmvQAxGiR8OvKMCJ5PvcWugpLTVysJB3sf+iM/0gCmFJnE5N79JsMdyFBonB6v2dMz
pE2N7pSE0p7PnIPNucireSiVtM8h20QG/0H6nPj9dX+8IYhLPN/j5m9xE6tI00dQo9+khvKwOXd2
V/+JnFYF+ff49VKgu7M85iAYPQU4/YDnBymJcGNanUgi7cy4YSJqVNicwo/NYfwuxe5G1bTzzZc9
EWE5HwKh5BD2CXncvIfdNR4P6zLNHtIzV4hJg0hulwiZm9EjP8w21M07w+/2NXsP87p31lazm2lj
mzv81hDv3J3jp7PgW/KGOJ/mjCbJoydimlzrk66wT4hMRsNOGeCh3S0bislkrRceZikAbvq0hGET
XelibkFQX/wYJYxzTMPoX0FNSWrzKOT7L2gSmSZS5mk0lqvqTNqTkcD1FU23jW81ArYmBd6D3jwn
1nQ9gsUqDGCCkTZglY1O1vfB520f4gVvvL3Is/AFjE8S+6zkaWSeJ6JPImE4ZPznLNW4Vop+onAN
iBe/8ZiE6OT9OgssODy5qhHVfRHB65hzilSEWN5HhfAxVMytlw/+lj7q8WU4xaZ+wtE/0ENmn2r7
T17q6zRVSoqufndI5HRdhA4ZYBRl1c5warEdOF1NySUKAc9JrIiWMa1OQDfofFXMk7QfC5bbuJpH
1p8LuNNTR1gGqU7dyNkKtkd228POKZZZAZIpR+9BZ9HbYnB9h0P8m2UEqynaIcZwg2R3Fa2q/kYt
A14zUh/3p7LIJ2YE5C9TWvF9FiVnTxSHxjgT13uXzsMnMemcZmWknEhi5QfpD4RD49QwmFsnnidU
JdpWwL4him+UeuKtE9AT6/Pc7DgRDpoYck4dtE3II3b05PnHgc7wZSlRTud/Y+WRZx0dhRhDRseu
6VXcpEKuU3w2wFEZeXK3roPhUPFScXCWNoXHZ1avk0pbaLN1VWcy5WwRGr4nVTxnAsqEV4XVt80r
nQm8PXD6sf6+zXTSVQLjUZieiJTYSCFLZI571Ys9tgjTZShpFdqUOXjrMJ1z8H0JsGC6TOuD0rl3
tVRSgE2v18ZWRg5O4liiIPFSA91+vmmTNejP6zPf+D14qQaWK9XbpiwAeYo09IMY+hL4tkiH8cy5
HSGbBxtCItmtCp4/z6wXFSBgBQ/C9VB81MUlczoLruHylBJljLOXeSSE/a3+CGVf+InN92FTmwNp
mYvBXMAHfGLp0riDgwJLipNn5vOmxNF4a6XsPTZ7pBHc6GvIuu0r8gIeY+IvF8RcLZZJdNA/TwHr
6ip2w6DDbZcvso3v3tuN/QL9JlRg2d2XrwHjbHwbYGU2cX+o/dd/DsJwaJ17sQEUIY4E1Xm6HsGM
NQ2M1K43fRLxW9ubkqgO8J0EkEJREg4LMIfswjYengauLXoXePA5tMB3pA2cvQu7mcqEFrG9rS0N
1oo+YpVMqtN1MLFf/FykzzIY1b+zED8eCH5TcdZ/klxiZKLOECBTAWdzd9r1S53zP0wPinXdaRtk
qCGEwBPLgKicSMqJGgSLM9rQcrZF6zV2jAzZ/54i/9WlDQsPBS/xO4xXSMgslIKyB1Xo336ZfJzg
jIdODMVhaz3q4hq57hhaIMjGnkcW0XbzX4zYCF6R6UXn7oEOhghqg7apjJ/t9r0ZNoL0h9hq5ed8
xQaIKtrOnbi3DX0C+FKzVcV77yXWwUE4qOLgag5MKkGpsUk78G426J/CEuyAOiO8VutomBfwRo49
+a9u1Jwgdb3cZL8gd/wsygH1b3vT722ehtB2xQd3zDI+BtMOraY/RR+OVc711xhjcDKmeSJ8o3m+
LAovmCzy8L22f7jh5M1AhQkY3tuoBjcs5afrm7igNb+oJ8zKS1BBTYbzNaFByulYZ5ljWl93w8t0
ofWmSpXVf5mmaA0irFTln3VW3NEXrvmwXF9ByL0ZZ4CNXAjNbvi1tJmUdIgSpbq0RXLvvx6AUMqZ
igXQ//65KueaFXwObbgOuZmZPHMrzKyXmwJ071StX+FY/nTIzLN/lwbNboLmkMHs5t6HQJ4xUfKd
rJTUtyCjaQ+R1fqCEaGfNQ5JAMWxblEHAMVRRcdpPznGOTPiSEOi/E/rSuWZafup44bVqFlXE8Ct
5719bcOY1gIhxy1IUqf2d7JRusyRSM5qBpDY4kmuScU2w1EuEA/pN4yXNsmrSQr13GPQr15SyBsl
BrWzdR+cdXF+4jhKZsdef+yst8jUapdFxs6svpi31kPxct+heVYKtlJZ/5JqLnf9aV44umlykVXe
lSeSDS//jXBhBQXmm3UwLYlHeEcvg7bTVJENStOO8NOKjN2XuU45w5UYH6pxlDuoJ/cKyRenWg9N
0tw9rQ4oYQLulvGHokD9HA09NiskapNiDrse4HuQ3R+5kuYcYjzYnXgsHz6pAKKlt6PaF6UA/1aT
VpI+MIUTMvStwipyCNXZiZj0VqqrBdFYmsCwbuO4+yuGSR2Y6u8lx/pZ2ipUISfeni3VlWFZM6Vy
SFMh/SmPdgd/unyJafIiS/QGOOAx++i8HQE1Q9a/Vah/+RmXBamhSLeOzin9+vEhePR4NT3OkcEO
8+6SEjrmND0y/0M5EDFGXUMRBLLOJAJgYylzEhgbStCfXjJFJlsNpVBMm0ovE/CmXCaF52e/vvol
0OE/kmPWJVpPsavGLo68TokQZR5JEOhJS+LhJOPgebe1jd7tRcexWORRTGDIjGeJquuPH5NiAhKU
B+sXtSwcul2+nCUbXrimUvrTlGtGq7jjteU/KEdiS0X9tsG3f/PngQcfhjVgbG2LCJqi1UijpB32
EFh4tnGbz1uvjZuCFQ2ndDfbCe1W9jF9jvg2IiZRBNPTafDinMp4WvenyT8HbLMY34zQjoMp5n5z
SW7vO2utR++rJiMqxR9HF59OxPU7VHhEMq85pLAvarovRcSkt06ksm8f8c1ft5p8yv50gNVo/JFM
QnMpyGafEPOIw6hhOH2VsEy/nz8k2VGmdlw9cfqXk9pD7tHYOaMLzF9TeCY7v0MZSci0CXPOaaHg
gJL11/aM5aIa0ncuMvH5nNVnAz/4HflqyYhK+3Av27MoHygdwwz/s0HX1X7zni9HVW79fQQmmWzl
Y+9yWMQ8t3AvUXkk475bHdqv31gjlqc4qWQUpO+aKYm54mU8vAzjzVkyA+xeBouQzw0EfDToyXrj
cyDvkk3/VublDTNdzoZI2zcJN9wYCvd+NiDJYN3mBxjmM5lg552wZjvQrODU8yZwIg8+7rSvtiZQ
A+eQbDxbqJ7WxfNd+K0ehjmuaBk/ZBpDV3UA5xrC0oJfsjopevSpjgT3jnY9B+q8iMhvpDrJNzle
l2AuFFatodJdPDiqpasgq8fiIPVLgbBBD8tGBqqp3/kR24XZ46V215CuS6ABE58dvbx9C4RN6jUL
WwIqvunzBsE3xrXUs5JzdRESE/YVVHfQ+0Zu4njfUTkD+LfkPmEw2IyXiCPpL/3Mz3LVgg55j5LZ
D5YBIpoP23plqoQa4vU3CJRx614QygQEefCvqDCU4mqfKTQpYzbQjWpw1c8BO5RepWbegV1I1o+s
hmOY8ZeHLVSC5lbMpL9MauRd10M/tQLBMXdDs2lh62tOzQ0hYJXSFBNKDcVELpg8ESm0F0QrIjY3
KiwpDmWIv82jlS10o27cmqV9KJag46Xe+8Sviwe+zplLE5bqzfhOz4jff0HZjGWFkZfmYn4DUQEV
crRZvPhLZogZCysUMeGj//kgD6BnxeKiOmk9lmedoqGdqDwSzdJma4fnFMpIihlvDXUVa8wnMAn8
ohyPKoz5eu0CgdgV7JMPDeAhuLJcAaOI+xj242iG02ojMa8IRcfh3Xmi4epxQiEjeZvnf+SKQwqG
Kq2zeGe1dNki+oTPMTFwUh5aP9iHQ+NmcCftS2veIsuTcIVfVa/64G+nVuFvghgt7HyfEVIeVYeL
VzaqJoZPlSmLTX7wMk24YVntp3+RCUnQMxSiwMvkDhYpLibxaR8DC8SK1eibg63F8czs335rDWS4
5cw2a0wOWE0uelwm/q/pWCLB3/Gdyfpjfkmx8cpkFhJoMOmUNV7yiiE4Ot6CpehxJ/+twnzj2W0a
gBn7xe4Iwy346HZrVj2QgEOrkBKCkijZ628qvWBwf9pPT7uIIjD+BpsXcKjwEh/moaHiqmY7AIPI
ooBfW/XoiqB9hli4D1v/6FFb177ABGH4z2kAPZX5e10ojTtlxuUqQ6hOahRr1PT3TaFZKIe8NH3/
x9rLxotzuBPpN51EQmCYI7W9EYrVzwJb1h2kxt5mcJrehRag4r9pRSa/vgWC+Q8brywyfuKcv/kz
b4OyqCIY/SJxQqtsTaaFJAzPGNCl9fS6iaK/P3x7W/EyFLyLoY8oLKM9XCdOXKll5ysLn636j+oH
+CXE+el58RPb4DIYXAZN87Dhn8+P6aIp0hCAwPGwIQSa8kkJuIAPU+45LRe+MlpVohoQ3WDvAhxp
HyjHHdAfcGtgH84mNVouwiJbNLitAfKWA/H04jUQc35DhpeKDX+UeMMhBGyfe70Bf7LwKY/Vz4E2
i8TpcrHZrrvxlkR/daA6IEj+4FrbpxQi1uoIxAk8KoxkFz0bHw+MOHhPsOVvlxguDEmpSwiOYGrN
mZL93xzSl3aCoSFdZ9KIkKzDul385QWzTR6JoS5Jkhjp2hXujR7U0eTbCa7LXFEKk3aIUGvLxNUt
rc4ompCiUITaoS0nY7NCeFVvHLEircGN+qFXq9fbl5hKgd/CEdov2+viUMOXZR3VIG5xUN7xm7UR
y7qIQx69/2PVq5aPo9SClIDfKftSQAUSCwLWMMCB5XiN6mLy1JA+gzhZZz5P/Nct+MyRCO3oxKgP
kdLjVtItZLIiOD5VTQGCTUNhyfC20+2foYAqw/SKzQW+jxWPQz8IH4+yPn2aKINTzNPIa2ujTy0T
zuVgBLypzyc0GwxZ+YPWDHjnYhnGxB+psT9w2EmBKcdBgOQv+31TUL0WG8MItsXVC6ZYSf2eztVg
YJnf96Vg1fuMoZshkQyPG9bZ5RVmDbbJMlR0+RLaRVPqXfLsTtNkUvA7dyaLv7hqqEaxE0ysgOZ8
7id7/bZ4FDpLmRiClGv0G3Tks3wb7lQOutaOtc+YzBH7lp5ObgJuEysYx+vMDv0st5r1LTHueNmb
MauhRlRkVhbLX0nfxd++MZXjwvHRXXGDazgRA0xz2VZKMfeTyE+VzG/xBOXQg8AIXAjtBfMyXlIO
4NjoIXDgt+hH/WAgNTPe1VPC+T3BJe36ZJi4ZP62ivGqMUoH+e3HlljevcbXILSaZ3yYKcAGZzmT
9zdCD5hZsbUqqkXOy2VDiLOCItzu47jt7XAf+qHzchwRja++fCiFodLx5WEUQqcTEhVvfJexUGHA
v2F5p+C24VNqXw5Z1FH9/gSgkgobMJOo6oofNzef/aejmd2AU/plMHIPXMYm5YKkQuoOuKg/nA6H
cGMi8NVjGcO6lVme5hZ8kHIteEfBhgba9t/tBAVazfKBSbudvVyIvvSEzdg8C15Spmbr5Wn0PN/3
mRDEqdig+Vz4hZ7WinDtqNETBJl+7wQmLw3KN6XsUXzAGv74GRc82a+z8Ounfc8+L/6+dquJNl0H
QmEfjEWyfFI6unzyeRgVuksTHEVJbifiIri4EFn1sEr9/exxlXPWkxNYutQrZvoHSmC1azkVj3qD
/Zt58RQGWKDbrHIsS52SXLiYuym4IMwKjqRL5MqDoP+JSHdvL8ajhJREK221I6/QflYV0rcOsHz+
g1dvWVHM0f+lafyILduA/IE3i4iXvw+ZCvkA8SxKbnhXGI88CuTTqNTEvs6KSsBr6VMn/f/Vsmo3
744dYQpbPD3JjPg2//WxIEb9SWec0C66aDxhNCOJJeo3+C/BUzYkwexAKXMjZ6+/wE8TZGvHRuTH
4Iji/FZXjdqAVfyH+G5jwqjX7wjIjOmt/vHjekuWxxSg8H7tYM04lFi8YLo+o3iVQ+AEppaGOc2z
rlFFccYKI1BmD9s2a2v04tyFnunUeuCYl852xA/ngLEhQxEdTPnT+edp1otxgZJIQNfRog5MwG1m
N3lyjv16/MgChtJ/uBu56oOaD6Pc5HZphhEHktNOVv81z4+kuWlwDPbByJv//VmtAobwY3NoWVn3
rxFBI+zJALZT5scYlgm4/FNCY1L3rlWRisH6XY9uh8pC4QN7vS3SY+BnCa7K8PrnZlO3rZ1606/d
bq6xZgSrkC3A4BqL2Mycli7zuUHl5DmK+vsi8m3fCH61P6rGhxjaehxL9gPqxmTL8yAT2ONgW3DA
MnJFHvetjZrOaRHD+OTBeWrhhj0y4hT19hPnSbCa5IdRFtYVNPI+XFHnu9JQg/IlYKUqsQRaEfGD
elvhTVHXsoVLBTofOfnXO4Hhj3JG1ZCpjCiPjnc6vkYFDQuWKticlJLY1jng6HL3h4pxHVLI1fQk
yJM8HEnM0JI1ZdDC9VdQ2+GLh5VE2NsL9qZIMcBPoBo2sVioQz9Pgo4TpvsjVaQUP++2D9uAY0IT
wjB8lzOiBSwEtJhr2vlS9vgbsZb7Bo18JhopfHgkejNoQk6yTf1SdgyQoPoYcjF2jJW0OPL4I5Qo
z12BSQGaIq7zmuV8yqu4pbje75zqEQcj+nLspx2NIr/Xc3kEbt6qrnywBxtvSFJ/wFdqT+OtCa4a
YZhpzIikXICX2xl6P4yXe1KOd8b/34GKmxxuz+cAX5Ecli1SF+gHrHc6IYuTmXBiLM5l6W3hkDAC
Kohv8O4DrGVrZi3oW9nmh8FBctWi0xBkOSbsidI9/1cPuR4z7d4TLF1BZgVdOs9cNv6KWud7POlE
Epj/1Cg9UrXO3j7xEOvTBHMd8JGY+OH9Q8P3RZ/6OV3Np+DdgzvrhtaORYEr7NQyCr+MCGPdYpmx
lmCwClzBM/P/lgcMbw54sdmWtRzdUr8ywT2g1UwFqEbS4QSg/Fnv5m2BUH9CRTvdJa3Mu7pEG4fk
xjMSqH+wH3wOVc3VKxMRe64fNN0MNd5raW13007qmZV4u2bN2wFXHM/24kscGA8QiM+gezAgjiQ3
ZET0JF18cZdXcT1v9TfEXHOj8iUK80qvexK49E0G2KL8Ao4ew5ebXxBDfxU921yVBN93JgYjbGeU
61mWCxcOWvBqmdmyXo9RY2YbAETeLe0Arpm4WelquVVblk/4SSOJt9G39+wvLRSYj/2H2+9m6srl
YtuDvCScBIJKQUhWOt7aW8+pfCzitCVo7WVuKCVAt7LBJSFdyfoI5of6dMFPPxjxCsiHmyWWlcr8
G3J0N6xW1P3rAVy8BaOwQQ4R1RMqPLFBHaxSCaCt4qWUmKhBWamU3LMrtf23gA8nMa8BytcBgHAz
BkCs5cPDDpqnksY4F0/t8O1evJzCvIZwH5/4UZTQUUAT7OLSBbGXqIHAzh6+mKAy/px2jkfsPYP9
U90uESGSZjzcFyioCULtjsC7qEGoExyUcoVNuZkSQc6LVKdogVQS2NwuQWhFj4l+YeUXc+SrSMSp
nyqBO1uCX2xH/kCgLQd6t/1CcXPG8USiqesO1IdFLC2UuAttadvQrPdt3oBSdHfy4b5aq35VZIR6
NzWmYQnicO1NnpQl8DdW/VCj93bDZFIO2S+2cVLK10CjC8aI+kWjCgeohtaooEKUluC77wF5TAcy
95bUiRz2p0d2d8aSZQWm7srwzuG/m3EOSzxxSrjwwyomij6EThyjit8SX+qUzlJMQTswqjQ4eC0u
iQWJaHGm/arcSg3KckgI/QdXzIW1zzAb64jz/RrdlKoM01iKCTei1UTq4uD2/nXd9A25CYb9Q3al
s7cFVg1CPeuBDXEgvPzFKi3EgeesubTS/abeuqo6Hg5oJcmbjXa5NoFSR8RFetPsIuUKADY08FAM
IDh7Y6qQUuePscfSH3K3l8A6mHNfMekfpVJb9wP7Y4up42rrUlFtyHthgBOigosyhnCOkQEeQb9z
3Q/ffUEtoMwbXnLV7I5e4nHS9ADRbV3gCD7/95i3rait2b/iwY4BDZcI8Mq557LC4NH8rxuHyhQl
joNvhOjNCvMzbaRzXp05e3SakGFsWIeArHFdfFvwUjvc2H64+Mwc2C23ytwYctGwL7N0PkHYHWee
I3aold78RKQAK6r+oQKTEGBzf7hmt9M+eYfIltVQ5KbU4IcEOl/kdpFNHn7RPoHFRvkJozgaISeY
dsAqlQupAbaWP8g9zVtz3QTQlSp1W+g31j93Uf/U5ja0WL4D2dMShQ5qGVqoHq6wwhy/VGMPef+y
h8mF7wb649ErASgsYm+jOQ0JRqAjbfxDVhrYLg96O8TfI5MjgiewmH5OilaHjcdURq2Lb8YdX+2w
KtuuNSquE9iuJU81GUX4Jr512ajHmpN6YcdhCelFwLT6O7pr8ojKt1ruaAQD8c945LKmJh5x5cjh
a9+ACzS0XcehHigh/BHIf64I3fm177437lu5JRCI3NGbZ7H67PvwItUBubc/REmoEicEfPXDGqO1
UKyOGLL7QKiBg3ZiU67FU7b2/KD5p4BoSk184W3R0sSsTU+oX8uhHk8wlmLFIepxiopxK3sCbF5t
VviJM9PWutUKFgW/RC22+g9kHWCat4IqX/eImyVnfV7mllLml6uYU66P606rpiQnvC7NBWGAFsP+
ptNXggGGFxBztqdAw4ag2J97aEAG3dUOgudphewnMjjFayZklJHOn9oyOO0RUyOqdA7BGMC+o10/
pP5k2ngUjc2MX+KLS9pVqsC/ojwcV+J7maLUFFtxp6r9xjn2YFHpDwf7YgRVOf1M+acwdbB1G7/H
okePBAvkKn5ebl6bpmZF6EJG1GFlK6Ia4c0ptVBAMakKVUimT16ZA0EoB6dWnSBQgFub+XlBS552
ftpkoTF53rXQG8OIMlmXSJKSQ2sQuZjkc7Xv+bt4oRI3G8idPJF9vB0IamZf7foUZy6fm30XzCRo
ThZUecAu8YO6/XWRRsVvvZ3ijJRQL8bkkB/44RuBdwqcomnubBDSYX7zcIn14ZzNwoS9FzaYZi4a
d8HkMCIC8tXFMJh1JhgkNTQ6RqsEdjF4cmsaj7mDGvf9vt5CDbuq3DT6FZa0M5ERO9LBgQc7d2gS
52vIKV9UDbVIri0NqtzCImUrZjzo8L56c8tpGpsX7NUUrHoMSU+yfLSuUYVZDkrGEMT9Jb1LQAMT
z0euGC+qLZ7/XFi46Dj67CY/Qo/UBlIzwlaf6LADuysl1I+Ske+eJpjVa5O/kH4zlnfwQAZX8GEl
5c8C1aswjC0paNQiP7FUXwUx8qUort3lI0IyfZZmA51u9zWUPWY8SH5N3SgHGZKt6f8GZVgk8Eck
Jf4KTpgoN5yENyH09747DSpPN5L4WQH71F2AKmxsWombquA5OEoNtmftvZX04K5oMwkN7b7OudHM
48oEGksBP2086xbNZr9Rnrq/+Qk6+Hqkt4B/oMHK/gTrXke7acXJN9yTiLH2Hz8x0fKjT42zhkeI
pgGkg8ksfqtE9UjA0l7McpkHRfUrD1nlmykIzovhKYvX38VaLXchVW5wyNppUOnSBS9vPNRp4R6E
8GLQRpFGa8t2/jhD0ZJBvBJufr9dz2TmNQygHoLHi9SzUaM37J70scVdWRRXx0G7VaU6hxA/a2ki
ItUdIDr0Jm2Cee+tF0NxLwOUcBG59MbS44S1X+4z7AflIF1Qn62rwmh5RiyKZK0ol8B8uiWBud2Y
kbjA4UH6STOoN6st+Ni+5TF3IwbIyqRAEbKwc40la9c9oHQjghYmlocJd8WTPFq10l0OJmZnumlW
Afs5SAXPs6jqeDO/cNz0ObigHE6ExBpBz0b22vVN96I2QjBOIFRy6ooD5SCmqjRUIo1l/+t8aBJP
DDmwG/3NbT3sudBy1eKhnPsd4u8ApPGqcbHhFEy2vaEZeE2ERGZ48sU6cgyl30WthTUOvdkdB8Nl
KSnLfX9EJs/wYEvYdH5AzlEq7PgXmJNJn5IItOCPOPsdbuLn60FXFQtJctaPnua6MeBpe/5Y8FYT
7AphGmKriHxYX2354rdzdAheXfiR16E7NmRxoZMfMNnG+5Uv0bzxPvmzNfeq6Tnl4rgKtD/cu8Wf
pBbXHXGSVNl4pRutX3+0pOHhml3OXgFs1Yk99JOWAkF/DcB7mU6YxtadpdyJSLqmJR15hsDetU1N
mW+TzJ5zsDE15D003/te/1w7ojKzv0iGRa3iQ+Au3kJI7yK4FusQTett5pyAsW5KBRd5ZVo1V+/A
n/8QB3Wm3Qv+s7s/g0AMihWG2ub8DGaAhU/iULnlBqKML8tUcLdDlrcZDW+QKNxbKF09I62c9Wsm
IpDesDEPuBPt+0nrlz1wpb9Dg4AkkFeWaobtzPWb0ptDTEJS1fSZAm9dnRy7NuTL14v4f85Jc1Qn
jhD/u11Pzk2HohINIm2gG5ypU1GTjIf7wPuDCB/uivsObg00lMdVSaZvbOAhwKuj0tfDORMqKD13
HuxLejk/Fu9xbOfmegTSyhI+e0czLUo036Tg+are+NxqK/ul752cS7jmserxFq1aCgZL5b34e2iV
fW6yP7sO9nQ2dpmcC94Mt8jgQML6b6tvridAWBOEaxaUDlJH5EGz2z+ytzVlCWcUsZKRx4qS91Cp
Mr9IBl3u1uDEZidV5HZzI/Ou0GYkBjlmWe/ixh9DveV7THGi8xp9aKypejjfoH6dqqNfSJnWd1EG
DdeuoR5/3hRYJAVlnf3FFuyx5JdPUZJeDYXwfH/qd1vndyW7MSTG1fnfr9wNhz5h6dLIC5oVYE0T
K0/VlBstAzLe2Aylai5Feg566ygYEuNAetkCNyEqOYFL/G+Lzc9kklN/y7l8Ys7LJXlNEdWurFsz
xlfa2xua+JFX7bLb9GOkuL6t0/sb4nH1nBXyXP6iNMcZjADzYwkJCUPwLfTFOHIU28TQvTs1G6v0
P1M6nNfzEqYlc7hLB7hbyTBm6WDTpGLu/Uw9EmkweBtXMlJtIXKw18KSupSQ8tDqsAYA0MUhC0p0
TfOtYApqjvM+agmryPWR+l2klS8zrLKdnEfpwJuYwNKylOjcWy7UectNorqE7p97FtG0N6r/Kjr1
xbi1VKkLzGsB2NbK1eXQps/ro+Mtp5KpG46LVVAME+Gh1R1S28GxF2KZvNLxrcUja9kjuSVWl33i
klpO6iuOGbtXdz7FmRBFX9pI8ozbxwA2THnR/Vyq1yq8jrvQx8MGzw20aJItrPja/pMxybmohwgj
BUUx5tWMcOWXkcPGOL8U5AqSY2fhmLhnZSa1/gKjltn7BdK3OIiWJ1iZovRMW/2t3rXIYEdRnmAD
kW+S+iq7F6D9jU8SMTOlNRSO6jnjjjhqL7BAqBHEIbowQzo7/2BMwu5bpABwv8UaePI7UEIr6QwY
KovbwddI5b5ECM5v11VWlg7XAV5JmIy/NoC0BQpd4gzR/RemF6W3eTRJB0LXLl+cfaKkKIUkf2Az
PeP7
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
