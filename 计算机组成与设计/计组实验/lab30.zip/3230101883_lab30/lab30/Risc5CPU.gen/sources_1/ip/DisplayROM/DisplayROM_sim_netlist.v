// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
// Date        : Thu Nov 27 14:23:17 2025
// Host        : DESKTOP-3MS8VAT running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/PC/Desktop/CSlab/SourceProgram/lab30_Risc5CPU/vivado201704/Risc5CPU.gen/sources_1/ip/DisplayROM/DisplayROM_sim_netlist.v
// Design      : DisplayROM
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a200tfbg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "DisplayROM,dist_mem_gen_v8_0_13,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_13,Vivado 2022.2" *) 
(* NotValidForBitStream *)
module DisplayROM
   (a,
    clk,
    qspo);
  input [7:0]a;
  input clk;
  output [7:0]qspo;

  wire [7:0]a;
  wire clk;
  wire [7:0]qspo;
  wire [7:0]NLW_U0_dpo_UNCONNECTED;
  wire [7:0]NLW_U0_qdpo_UNCONNECTED;
  wire [7:0]NLW_U0_spo_UNCONNECTED;

  (* C_FAMILY = "artix7" *) 
  (* C_HAS_D = "0" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_I_CE = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "0" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_PIPELINE_STAGES = "0" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_QUALIFY_WE = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "8" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "256" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_clk = "1" *) 
  (* c_has_qspo = "1" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "0" *) 
  (* c_mem_init_file = "DisplayROM.mif" *) 
  (* c_parser_type = "1" *) 
  (* c_read_mif = "1" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "8" *) 
  (* is_du_within_envelope = "true" *) 
  DisplayROM_dist_mem_gen_v8_0_13 U0
       (.a(a),
        .clk(clk),
        .d({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .dpo(NLW_U0_dpo_UNCONNECTED[7:0]),
        .dpra({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .i_ce(1'b1),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[7:0]),
        .qdpo_ce(1'b1),
        .qdpo_clk(1'b0),
        .qdpo_rst(1'b0),
        .qdpo_srst(1'b0),
        .qspo(qspo),
        .qspo_ce(1'b1),
        .qspo_rst(1'b0),
        .qspo_srst(1'b0),
        .spo(NLW_U0_spo_UNCONNECTED[7:0]),
        .we(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2022.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
M9ERyrMNmk2Jjyg6ZCGYQpTqx5C+74+ICn/vAQ5KoRuxJNbql8tHJjFcOe3FAJX14Nokq4wtfvZP
2sPXAs/eYYzjjbnt4nx8oZRRPy0XyDpvba/qxyqBSxjChIoPMDwpXnxi+chZJU5N1zCNt9FZPAep
nLCjMCkQTlKbP3cUJIY=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
FBAg02qOh8M8uZkNvwWHoY3ELncwvHjjgL2y2qLN7xuxxaPQj3LdyD/IETTPdSjNCB/rhpJxbT1y
U5fbF28Hkp+bzDuxeTWPX251wMhiEmdm4jhyMl2z+GRf2Z6VJ4bVM5bieaJvsbjuyQ9Az6TDmueI
14citDEbyRCyJD9EiVckdS2mZcTl37oVFebKnIeJGmNjOc2XrcM84JVJIG5iv3ryS2hAG9/84hEr
u3DYC+xS2w5swJXVSf0zV+w8xZulS3PTPLELIM8O+SEFdHetZKnrgG1aJ7V5xu0RniGAsyVwVbgu
M1jPqNLyU+9kyETKfG9jcGEIM2I2gUfmOvRs+g==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
TYvdYOtu2OcY/hp0LCFlgwGgJeLJ5MSBDPjuyI3760LiXtklDVs7CUFlvRRXMgAzbHlMXbiHp/Xl
cvmN035ayt8D8gPWRXxnbQf3kRlW6EIFwFMZ1inL9b5f47gsuvCP6MaKiTg0W7+/ZeHbM4jHXvRe
b8HXvQvK5kVwtayEwt0=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GkcGg32vdV7ZS9x4Uw9v3hZEcxD5hMmQXUqa6shDPbzqUGIxrKpTOb9W4Sgi8rq+qw7QpAZp2JW/
MkYAH1WikFlf+XWG57y55EFV7oRoKQDh2Yz0sZEwVhwTGwSAqfnjrmPITofdG5eiey1ySGprEKsT
mqWAV+ZN7TkQkKup0Ukf1O+8giYKT/7UibTRqG/CT9dgU/4atPgYh2QjNMVrsAH/uzDxh7stQMYe
nkjZBkpLWOq7mxEXTKVtYAD/8G5qCJELRcvCuUKYz4Une1wDj+L/vwRK3IAdWKQ+/5mvj0q5XEm7
IKu5HYvalbySwRWzaB00uobXZorNhfwSv45jHg==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
JnT3Bfv/DUBx2mIm4+jpmHjzhKoX4mNpcc/lgscv3iYrJw8Uble396hMwPsVZ+kkAsmYtegNCiTG
Z7kqnoNeWHv+Grdizsq0QM9S2KJ5EoZhjelE+3Cii/ztNHf7Y3c0nBPnioUQ5YmWk7vgoQl3SJ3d
vwD3G0c+fGJBRpi14hTJOB2wtu4EeWcJ1f+01LjKINeucLlwacjnN0tElyRgCNKfsRDAQiMqwKqg
XCleeNY0cyLXGI30pXMpnbLizYlNKgVD6DSeNaby0dhW4phR0a+9xteo8l8eRVzTO+VSOcYSy8rU
6Uj2y0Up19vcq91C+/YeHlh24VwNI2TJeUEDwQ==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2021_07", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
AWr8D+IaT/X0jMJSrwmWnhWOjt0+8oyULINYaH7QGBLgqKCVtf8rqo68R3/TZ8gTkN73fZOx0QCU
3WEp7Ga1gUsqEgy+2zGlncYhOzx62FJm4Pm7S6LbE1qdg3/9Pp55JLaf1ouYlZccQJ+yawj0HgL4
zR0T347Zg2aIFxQZ28icCuJbxAZsZgAT30scXsTMMvXlQQ9NI21OjirKgHRn3dldIjpkL+BrVBkQ
Q7MMiTBhpCn/c+WXk4H9BPc3vMrVoh6r5oo+e1858Hk7osyxNI9zuACaGwdAatsW756kQBMsQoUj
TmJksSfucjrHVSuLFffpztOARH3LXrhZcCZdoQ==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
fPVwMHnHe1L8weZTnbBxjlAabwZZnO4DZSHaO7tHGHAw6U+w+7Rc3BwfQXtiTyGXP15rvoLhvVpo
i1Tzs4zrV1X8vlWrxhS6XA2VO4RFkpCjmnHpvdgnW9mpk7w90QOEZIWZQST/o15t0wDT/kv4J36r
Ho59mVFCGQQSSYx0209u6sG2rNpJ5HtWMM+tDEDHUArucrBmPOoZSq0VSQsTHtjJQxr3U5fv9l6q
aEBWkjnLJ6zqLkt12B3q7V3iFORPpz6XNMqA6wzArzWirzgTCw3CduiSAgbNgoGmV4eNrVb2DfOT
5V4ni19GigMG1fHCD9dNPWGiRCWpY6iiN6iE1w==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
NkQB16Pku9sdGFuAkY+DjFhWzKYvb26AsK/VO1//MS5ztnK+V9d/0K8nVee9kGDNC4zorSd1NjRc
Jkj/JJm1k/9QiQQwOSB/94zKWUyVH2Rvw3UOuaTu9pWRQsIdmPNwXBKCOF5L17HHGaNqYzvHF7YY
REIp6VR4HcyLq2beYXn09Mq0f84obUr7+CMgh8i1SaLa/ydMPS9xsm1i0NFB3qcEC0dDq6xklwsX
s198UBI5mBJTEUKi38eytWXzQPFTmqdlD3Qn4CgstxSdoLrFHchISqt+L62U4xU6aVyYXmVaeebF
I1F3MAXQZwZwGETW7RW9t/+3pJtkjPfPtdnqu/Sg+zP+vLjSV/NcONctKnTj86/z+TTehoSH8ccr
BsjV0PhAtR3+RTr3VGkKJoUNeE8yFQIHlES8UamuSNMh5XrbmcbFx22MZ9gLOa350ytm1N124jNF
V860l5gGbt/8NcGf8I3EVPrYblJ5ZLGsZkVg1cKBMUys1yMm6Ci2Mruc

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
JDELzo7luYHcwIl8sAAMR3hvm1tr+ZaD3VKTvYj1uwYFwuIPCkUfjVi8OMAgp3Hh/R1wDZSeoY7T
xpO0sKF9MsovKwwArnByLL8zZflfJIe5AmC+jE5a8qUxydp4liMdOypRTLu6U6EUYUwSj6VOR0Uj
deCoQCr/gVZ2GdNKF5sKZsGXZSvx1Wag70BiGs69qhgUvVVlpbqpNRSB0DR/2IuSKCHhkucLXiTk
zVS7zC7GiyNYE6l/Yu5Ov25Cl+lY5cMZkqKvIFm90UiTBNYk4No5ofXnH/E0rNcbydv0BvWDmgKt
NXVratbi0ztKLb27z2lw5ZZzXCihB41kx4VjqA==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 14848)
`pragma protect data_block
eTxJRkJyN2jTQprBiepbScA+T6cYSWnHz6zrVLyl0O8qECXIlhJX35S89jixn29eJxiZ9Y/FlKTI
0TashjG1wQqmBfkh3SwBePvTtvrJS/yI17UyoWTo+fPNrXb0J5eqfOm3RVxjs4/jUiJ1sSREmlDn
IDMj9r+RnZRhLMMwuvWfg2CmPWoeAxgBy7gOQ1QBkNDi0V/omCnVg2aq38Xo1lXeRtLprrrTS7V+
U4hdJokCwqO4yIy/6aTR4Ghi2FeBuSwKw2QQqsov+wVTflXctgqqRBTrQ41KV6AlLt0D1SCLQhzb
xw9hm/xYky9HuLMSSXbrgZhLxTxldSoSP+3a/bIiFeZ1In2YhiwjNfFZqh6csJAHRKwHPGkVAOdL
9SLw/ObN1aVIzVJD5WJIin0+oiI6yma2UMSHsGZnPeFW4ynZ/2qEQu76X/iaGt7FgIDqxfjk6sN/
66GtM/H3F6AvjdXCy/N78y67PHAQhzok3KpBrR8nRIpKXgbNbqpo5vnWyNi+YlVN3ZRFEiFnYYjz
ggWiqAiEUO8qfd4nM6JYlur0BfUr3MvjSXEZLz+lP7MP0hWrq+4ON/szGKPxe0EYfKZijkCtvrpG
zcUqyy4G++vpEkZAgVCMF6g/Q95s62SHLHrrVMoAOtGE/1kYMg9Ylz8AFrHPCCYnccOmthLgPuB6
N1Cv1TyVhvsK+mhoF3ivwssBGl3DSIyeQ3MrVBaT8dlG6c6jK65feOYUitsW+AZE/kdfBrmMCx00
MMiLr6yBbXUIrJbg+OvIEGAH66Fug7Y/riRI9EaxsP8K/bgDA3yj6rCS5OmByccGT2hBva+TLL0F
bOWug7eKHv6e/8SCInr4y8xyqthhTaPAZjuXDKJ2hXnA6jB+bA9wIGCmthmR1nN80b6IxOgfDpvW
jfVgBUc7afJJSVSTrZV8DZdba8a5PR7FuPKRYJHY0pPMAkkv5pmCK3f205lZL/CWn/vPzl82VY6V
Xb/VPlaGlNllz+HBUwJ9uwghczy3IuX0c85cYI4KQfaIu/qNeZssV+/98jeZNX7zSk2l03WBb38s
H3ICV8rnT4Ky7Hq3oZG6eqxiB0C+cfxlOZvOBcbmis/Afqc86sKCfBszNg/SS+JN2lohBmIA1iGL
uCWsE0t7UCqW+A+8d6A6DwCpxDEVDDg4njhraOa464nlOMrVeUMcu0UbEhiN/xGDV8m3GEC4/L32
JzmFnlEBfJQWzJvrRNzfsDU2GMQ8PDPsUbT3BTjmTAp/XgJXEPs5LlTXhvoxHXrGcHSRYPjP0BLh
EsfcDQj1mV0xEbnlB+WUD030IPezLEIcuYowbfDF0ngFTBdM5FC6avNC43HZl+5I3dSf6Xe/s4OK
5Z22HqwSJCxy9X7vIM2eIcWpozoC43UuypeCFg8HcxPQ0Auo+jV/1ra/Vk5agC4V/1o4rBV7+e3w
DIRlS2x1Iw2661ZpkZP5PFthDXxqm/EiKUGmUdHCZkWd6CFFtlaqpkUWWXY0RaVbH1mxKZft9VVx
CvI8w1FLXvbGNDybkYrI1MMPjTAnxtvVE6ICERRCK8C6mgn1zVEJTLP3lLi/re5qW7EIufvnGxoG
YOyyCzU8cHvWGByR0iaOTQvckTJmfZOGBZP4AH0OmBi/SsafBsANZM75Cno4celPWOm2g0h+IvbI
3c4ueLiTC7W3gecm3QyAde8m4JmJoASp05PQHrCnNaNOom0AEZxztkbFtH8t6W1vMk111LiVmgqi
IsY5PUCqBoNw/+nHvCwWM3xxEPio7QZTFPoNF0VMVyFqrKjnGdLbHBzj9Tbb7UedffDCeM5R54Xw
vzBhbxyh0ndh3xW4tSKmq/1gOdoDgJyK27lE69/s2BN26rqSxuoF9f+vXRaztX4lJZ8MoD7cv641
0z7ovL0ETjXNoW4EC/BBbhaxWm3pX0RVvQyvXHdPtLIzd+c9c/24GMKzC6op+E1s1WYiDHs5V8gi
KkhZMIp2Lk7Rsalb2xDwxJLrTK2h2qlpRR7IXs4o3NxtsBvZiZ3qrTFiM+91glpdjtC+qhBBkNUc
Ds1MD41xmI8XmLiZFGOqJWygUwqL+0EAZ0f7Fii5loGRq3LLb1BkuZMBq7/yKBY/O8G1RorZPehv
zeB8zkIJHbK7ApJnqbjxKFNcF0nVO0zS0Ird/bE4TzjzBKKgVWdzmLnK/XQq6PHSwDv6nFyZEout
Mhz4JMLqth8C6ecjfmyY16NQXE2Q1SiY/REBv9vXF2GyLvVAtCAw6qtUoYtZHHzXyCiW4wPGvAsr
Mm+3jnJd1GSZJy/OyFlyZDpR4TnWDHBYe76/DN0Mczhb9nC1gOBHixjADnNlr/pRBQ5poMvN6EIs
TYWRUlWgLfUy+xow2JPgRS9c8cWUiclg9P0yokdp+LmHIL3p3tzq/h3EVMD5mO9jodFEpad8cLdR
NqJH6tQ1Sloc9Cmj5zcf98amDacCuxviwbgkHLElpiGkLNJRfH0HXuTdV69l34MnXOkNHGOqIr7V
3KkvPlUDgnNw6r6MqKrQOmzlvc4XptXRCdVYu26bwn5i8N3AwKyJnLZIHwZkVZu7UeHc5zWg4cn4
UVcY8VZcHbewiI4gbamXDUrhqAU01Itrl7aqofJdRIDoaxcTWsvRBFN2FAmdMQPzXOrvER3qli+R
M+z+LaP314i8Av7bua4zXPxLvsx9PJGgwhYc569epAMTbDZtiQiQegrEzH6Egn7gbhvJmVsMYvb4
gloIVdPBkL6L4hs9psoRynlxauGr4FsMfzoifQWrLRU5f9ocnXLZ57O+tQF17YSuvwdhAww2U2Hf
m73JelORs9IOnZ8wfEnIOeaThRCSGzN9sRJVTI/GOuCMEmzqleXVivvhZZDVBPWc/jFBL88V3RZd
23bDHG197tghXTdI/dxCBdMZH3she4gnmDS2P/SYZYv5VypuWBDPqj6fjBDBPSpTeNjwpeEpmBgK
99ndzCx8iqsIXlJ6/tL8jXZuBnFyn/ykgvAlkkh9QaT+AY4bYjpO2SOsIf0vjPgAv2MtNSN6/MlF
sMC6qB9Hf3SNqlTEcMLUFYllk4ZAy2x0F2sntnBaRqB43a6PhORDzLr5/xJRCy3ZNvFgADCI7g8Q
ZxZrAgsLLdJFbCcd9ce5jOrtoC7/hfVYQgbQoPqWN67a14Z+XUaiGQ7bhHX864j7W5GRwO9sqZoU
H62Xn1W1K4JADjP+Zv31gRZ9FB2+ezts1etVX4G0sa+Tvb5g7ooB90/Q16ZEV9RlJFZHtMKAfhFD
8d8RArvOtaExOV6RjfEKG2OTnIG54DeCc9qCVetYy8I6d/at4omW0qL2tc2YnfluC1yC0O+NAtG5
Ll5g0yg2ZbdqIUdVD6e3u51e0OE77G9Jow3ZFonKTYJNwHgqcOJPcfCOxzz01gF2VpWnXfEeHYyT
VRad+NI3DMSfgXz0Kx4V7vd/SmWdX0FhygJYof/10p6W5i75AfxAmUVGVkT7zkUfAqV9kk9TWG3i
J9HeXR/SHrhHXdLi/cSxpalnktdruscBfyRYZc0RCqUeQ7w/y+IC+qt+8CyyQwhgD0WqbQFy+/al
dhdvUhCfOnAsVZyOhTLBq1B3/AVJsZHXxFCWfGZXm2g8MW/lcnbq47xAQIkGYsl2slwfvDhtuzaF
MdLjj4Pvx+GPAr+gcfb3nqqF5JqEpdBkyHhbcIyk3WtkrmJnVB3inZ99HMrkx1eKUnXMstUteGLS
Mf8YxZZpguB8J52VGkvy8ZlzNWdaP/7XeSlEdvOvNzUyxuwGQDmCnFUDIoltHsljP/gZssd2BMpA
31WVb1ylS1/2b2VmvNm5CXLhyI7lT7LsDIGfuInWCy77CrJsrKPeixI7dWQtPKnO6bcvGgCfarWo
c4Dq12hyuN8vw6dt0C03qZUfEPLFP4seOkmXYdTA1sr6K/r8J0euh/tSvp7arhSXsouv0RjVFL5d
b/6HTV78UAJDOZ2Os9w6lsS3PJyXI+/YKLPMIT0i3PQGjItKY7FXPBIPADrq1XzBScBhUH9wMaqc
J5mD4Of2ofWpfOz8OqY3IybmHIPqTh+7oGIR3KJR0aodnE3DIPi43Z0WfzPqyHQyev7eE0Tmb/pQ
w538n28qn7Xbo/CCKLrQJys/Y6S89U7vAmX4LefVyXZSNQw+xoJiYaJ1vM+K8Z9WUR/UVs2tLD/T
AQMG4gv4FWp4CZQd2oAqNxgdSEPpafEiuJBivqEgTMUmkuU/UISh8PDGazyhh9y2wi5Hf1i8dLjK
CF9nA77wFhWAMWDPHuKiBvlELZTm9GsT6jSaS45EKI/O5rRf5ntu+/uzDt07qSgooEg/tjm4gD1C
mOv7e2HnVP1gkV2gDKs2ml2cJ3Wu+7nEkP1Z3mP/Gbuzcvy4ydErxB7oPAcd+7jTelv3tXckPdGh
RRe4Tep9+C+hr1NUDV6hLws/7XTIaNitUNz1vlYBOJJOijBRQmqpmnolnzVUVzjJ/2pBWF/MctbU
YI5zed9j9sOcI+RBBbVv81Av/aVE0hWUGpolVBUfaFtTys1mRWyfpJKYkfnG5xmORk5RaiDG+IHE
QQUrQ0Kj2OowdyLZtDCb8wOiOM/F31cGsXx3DsVKFbUKGFJEVahXHb+vBvpeZTiNSWrac0DqlrEm
eMFbmA8dElIOqMLdtJBWo3x2LyEHfgETkaANMQxcXCHGV0ROZerzdkws1lF/tT/WjvUVy1EBviv7
SffKIbfJkawj7W5fSAx2IcBOe4wDQgJTY+KZ9EGMWvDvyFnSDnefMQwn3VcFBpuKb5qdqu6H8XbP
rckJBXXRMB5IBcSFRKC27OK0la29z45hffKgfTAcXA+zIg+iIKJCwkEVxClCgK1tYuL2kglOFrN1
bLQvZKEpcJyUkSZO4NJHgJOkYFi4t4Ulw4Ognc8rw3F6DoSJRoz4GfPlmDFDAj09SvU5i2oR7SWG
NnKvCw8C9mRr3t6ekFu0gAEMihyG+wTxByl0wBdvqYB8oAK5MUNCq43OyNdoKKUSZj0zFlDO168n
wSHerxlF+olaJXj034dkcb9pEN8FY+QfGY90Uq6F79nONZqX7X9i+Fcg9Fd+esK8wSUehtB9C0XF
hO0Ag9o8g17DFuS/4FwHNAM3Z0AXEqyuMWCBgMyKfUtNZh5IOe+AfhqKm+cqdXBjg0bOZ3mh0c5F
A610z1njlEqyNxEtJTH+49VD+vmoInVhZMw+0LCJc0FldSu62dh42OHAhN5elFTHhEPbfV0tjX6t
MSVQ26aSc0RPXJdFd0+76KQzbQtQCN2PSjV8g9nmEgP1EdjBliA0XBrs+1bqoYcnEo0Z1yxtZfKs
lgfR8H3Q1zDlq7s0ChM1GLOrd3Rz5XKHmI0izB99fjspv+mmiB0KgMCAqJm+fVZKykfdXmQ//4Gp
5vZ2Cny/GFOApgq1J9mmHKR6x2db/qckeXr670n7SAPL+aT3A3H3VlHmKwxiyD6Yh68t3KY3DVnw
VLzUDGs5C8IkXchQrvKi7ZIGNAAR7QsARuFcp9qmy3jPxwcdasjSSkhb7reOkMrDR7S8qnMHNcaC
1v5v8axpR/lRRp0Lb9DxqGrom6Fih2h+Gj68gqk4fTB96VKDG9NpjFxFQEUTvwBUik2QJZoKeA3o
BuqkuJXfZaPCavYzOP8/2VA9gtxwFvWQyUIjEsFE5Kgx4WXRm7euWPmbA+J+Wu7gkWtOzgHoHhIQ
Yt+0ytCA62HuHZHvxnYA3JUx1hEzpYilPv4L4x+NiE6EReYBbVGFVhoXyqA/v/MoiP6iFHtK1Lmr
ldmMKg/wqhioSd2Va+xqYKwbLA7ZglZISr+75okCGr81eq7gXypEReKQBM4gtdCF7QvNPnGOZAki
6idhZ9nfIPRtt5FjA9CgkbmgBOu9u2twIhLuWBpvJRiF0XlbTXs3tWqO8hUFGgOhy/Led/ZVqdy3
7r799u2ZJHevu0mvArBK+h25HJ5uCzHaHQTwjApQAJJyKiN9ws2yNW1hI+t3Le1AVM7gQCA68tHt
EeMaez2LLoMnW7MpYa4Xs1Ocx9uqlnz6Buiqb3gJFPCGcEluR78Q0m8wBwSqtog4YBBFZQ+Gc0aI
XQY7oDrX6+huMGH0fGO0//fT9SAcH39Uvu0P0B9d5WiWKFCS/f1xFQyuYpae+/M4tTPJRQ8augbh
dwPN2QKVHJnrhdUaSKQaxzfNCgHwVK5MqmY2+Xykf3Zaz4ZleYT0omajHUHdk8bQUqVMM6WAq6De
H5FWWkIEva/hlrFMU513M/pOkZ3hWKhPzeacztY0H+RqVkA8n/6g0ttfJfU19obDVxJI0bFYfA4l
iKCOG4YX2q9JFmRb7dq3StwuC1fyG7VRLDYW4jAu9tNH2dtUND/9vd0WLWIi5Pcu72xN9SHJrORK
P4Os4b+wT/4E6vEKPEuLldmdE1hbpdNhrMb+Oy0vXXbO76jR4nI8E4K1+V1Io7CjAfaz+oajV3WM
QjLxg4mkxDoBiEYb9T2yZY4ShapaudiIRi5QmMIUMHuZ4kkjf8EgZDacXf9o1voMcvcr88kON7n0
59e88sqGfl1jwrj8GOESfHE60KnJss0pzgSIZfxic1DD4J7vS7ynTHRBdNVHWT37BItY+T11/rKQ
Y2s6xm5m8JZnzMe/t3egJaWvXofQYm8XzBwCDu5BwXCvGiLAdB2na+klpAS0gh4bdDWi69fW/14c
BTJP1uYaxLLjO91EQCjyeyT0qylmFtrUb/WIZjpA2ZpXV9RpXB7uS8KGqFCZgzGfW2ds9hyEEO53
nOa9GLgJDtXaamqi0HGLyXsSuH3oEMNQytRvZxeG4p3BpI4HvzrwxhVm8hHKMlEUXFHmfLbFLgPI
u5k9mdCW4awvL3PXDiEIv0RJ//szg876eXn5U8+Nn7HdQEkltg+2HZQ+zxsbqznLoqc/N2jmAAmD
mVQ+1gnmtN8+sIN+IlS66bDXbKh77JCWT7+ytktVxGLz2GGd30LjayACEb/OmgrB/iodungdRrQh
O+4cu1t5mycx+68haFa2VN/XxIc82umAc5+ILln9LnRcJmDJftMqQNb5WyT5EyWqijYI3TooFEHt
c1se+e2d/aQ7tUTZEyNw1ZsVMrdzdVup37RoOOV1zGwCgJkAPLl153exmZJ99rqI4yrvj+Jih7Hx
+q0V479SEdua2Rvqc5BWlLSqKKDqa0ukhyBtKGXsrUBMwL/kA5l45cKRh815qNo43S9azUZoWLdL
zP3oNuJfRgvQn3Yk48sfnqZvMJXmo0Fxlx6WtG9aXldi0hz5PkbYuTm2nRGyYSXSwy1JgDkW7nlj
pvaLA0nDqrx736eYMFbqznBTLRBf7XvAaB1Osof9QB9RDOyGUPQgCQwTCmjQeowGkrq3L5M2LMcy
xKe9mfFTddN7ZjBXqrOq7TNWF5FvmlIa8aeo3XvJGbypDzsMWbaJx+sjZU6BSbmc9/R2AJBospH8
cao3kKoYNfwfne6mPUnEusGhpcoJRWJhjYo9n40mfFoszyhaqTg7wbC43n/k6ek1Aj9Mu16P+VqS
2/HNzxVyu4rtKDAGKKVcizkOVvejRtGOF2+wHEWJbFVmi07Ehhc1l32F2Ynq1cI64IxnWv173uRe
yCyVCr3yHCgAEQmgBICqmM976WqwyY62sXbzZFMcrBSs6xBJO1Y6tVmfuV++9GXKsVixfcKxr71J
Opt660MeoX+zuTL6NCuZndGFQL9benVWIqm2Yl7518X3D+zXZC/KblkHW2Mi+bf5MVdoHVefPpem
U7yi8MhwK7xYxJwONbdOGBoyPN3vzW4sCtmXI8ZHBrRgK/HATjLpwjff9ef3fiDLISjLAeZJwypa
ZsnOTctT8NZK8+rb0Jfq3gRRBKiHr+b4p4uV6RBxxRf5KOU/a66EC7E0XCoNdn56nxRZNmO2ix3Q
jPlHxI4B7mCTV6f4XLSEyQLtpKRHy0U5bCj0940KypEDzF2SV1slomDNLzKTRZLT4pE71eSUSODF
jLtt38CRotq/DgyUpNxcHeAbrRgnCznXvn0lquhQ8sMVr9yWBN4g2QXFYZEk6dpaWGCLCTSI5uqj
3Kpq4QxDSo9vCMctiltWHiICZg9K+XP5K3+zahz/i48S6Ejh/gfe1ajy/16zvnP01qNZQGExrNhN
0aSJWUqGTt+9/m08vuE92je8P4N1EsyJOtvaOIN42Sl34pSyKevG/GESqHtacYjW49338++eC9GX
TX1nEntjT4uy1mz1MVbTPUnerfFglE0Hm+nieqlUdcVG8iOdSCFqdbxittoZx97ssx8cBRVFTTuY
57FpWqVl9w1II3JLnZFNQ5K2skmpGpysLGDCxG/Sq+XgOUOcb67sTbavUcj/Yff4FhHKNOxqeXuM
W2TO2RYOZRcWbmYoQOV6yXADHEkYljfP4PhalQIJlz7eT9XdkLpoIN3C+8Sd4YPD1A3eJJ7hj+F7
Nv3hdeGGpMT0T8GxApRiVk9HhM8g70IvD9awyaju/jPCnO9bP07pDcCUr5U+JdKDE2rcxYleIoQr
B1FZiEEl/IHfrINUk07Lqe/tVLe3iiDiN9Pko50C6O1AV1/1wZfQXC7HxSPghIfV1RsxL4uCE1Oi
5qIkbD0CPQ4kWf4SzsdRx4I0Jv9+/Q+GSh9XQR/9DpKCry1SfGue2Fz/HJvF33tiA7aauOssxufb
c10dLRPj/ms8P/MGX9whvtRIsVZbmehX5CUU2EfCXrPCUJt2AcJtCv7+tPQTK1tliqgW9OBfrUgJ
/gEnfR1XU9j0OV/CVU34teYEdZNFD/atYWbCQMto5JRnW9rIeCrwLi1zR50GMjMexI3vNRgXLuXP
aXelTAK4HDNKEj7Vgb9GQO2y1p3qWhQz0xQom5agJuESwcnJHmoe0RE6jqZrJ5ePMcXkUZPl3FEP
wARq9SovWDO+2VQmFgIFXP1TaIA6Lc43cTb/gnK+X0Lwy19CU/FaVEm8J1wp31RUkuQxEGnJN/j4
s7dOYIbqR/zd9KbnNVxZewA/OJXOm6di8BgKym1nqso+ek4SIRPKr59biFF6nhZIg7XsSAeHBwqY
Zu879mAVOcbDth6zok0aqDUBClaRz+3XoZ5IVpNpqNRXpaF3hRtS45GosYIFMeWUU6ql1YL/S/ol
xra+C6wRzadRTGQv1myPlbjPCSEz3chY7v0JIpnNa5AZ2FfrD5GpSv3hcBdR0h/F8FJEU8U0OyD9
m7QLDpSm2L/iVV2PYcrmz6zG11MxAkKC2giL8Rg8Iudw/CvSkfcrjLfACG4hrhJ1p//bPzFruRYG
HJXkkGfil3ysZGVFt8KO4PTuG1tB6H6/XxzpDkd+qh1kazl212wA0YCripl94tytaHC3UwnlgFbG
PJZDUjgMXoLNLkFh/7Zjqp+qWi9thC7rcJe39ek2IHfJWPO9RbEiXzIGsDNyrgiJw9zp7hZRft+d
ji+9lBpuX/rjCBarEK9QloneC3csA1U7bHaH3z5X8uH4X2J6NOPZJWzZq4yFRvQ+ConMwTZ5ApOe
ASRQUix/M6qvudX3Sc91ooE+xRerIGwk+uWlydVfgRQ99ueDwx9P78s8g1kQBUOvMV6ef3KOJqqD
LwW18Liznz3uwHXxqQuaaM8Mb0FrdZU0aqLe8hvVP3lJctOgpTNEh/XzdXEmWwdrSbu2+y7meKBH
iiu3qAS32GPudzicgqcn2BGPY47wu0mp3Y4W3WuvaxjOl3dLSt4C4MHbU/hTqilDtrZdGquG2i3C
G0nulNNDSZ7+WenrUC+vSya4O8Z6xCMifZIjMlUdzJjbG4b5FFUmdmKFSFpWEJdA0px47Yq8vXME
6uwnkFO4GpaSpoLtyKmHSTCPndDBKsPQ4xY8/3yU0LA+Or7IzSQ43gNY698ZkJArA06eeEsUFr8n
HP0UE7yGvkaaBiH3fSr6Vx52t11pcukzP35Et2iHRz1/Kz4vmndrq6xPeBg3STUzt6Bz91LvTxSI
EPix9HlXyGN/AXzVkYH5hHchbyNF3D9OLyRszKgOA5S9E3q1er/i+ia0l6b/liCVttDYElmDg9jz
fI0kLarMTFkJ6Pqlslh/iagk0WVRBGkVyEaiUTr7DH3vvFpKJalJYLQ+/Z37rPXL8tlBOFYRub0m
vBU+ktywBe0khb8lj18t3PyeRWcP5JJbLRCBaL1D/JUzXt6GKVmBipQ1FP5tqfrbo9pB9p012jH4
36C/TWemjGofu81BpHh8JsQOuNJBVwCK5NbXVFKSVray2miPBdL5VhoEDgTbnl4TSlLY8HaLRE4G
wLBHwujGIZ2o1dv3c7kJapPKAwK6NX+Dt0w3xLPYIGOo/tDaep2IeqOkkICxRUmqvj/O84Qe7uRL
oyMjplVl1viGdxboEagGzBBm2sGxh5TUTN1CehOTQ0hEUAloXDwPZJ7yuj9yT4EbSD2+v/qzgkcz
xHH46dhvT2Y/+wItaPaY9pnGQ3srjhubYPqobfADQKIfCE1F3PEryKQzcvLy9CQlTNMa+eTJC7KY
E67Eu/XZY/LMc0sVAOPFhcgtZBQ4LVaHWzc9PvV7wPS7gzMGo6FP0JOMHgDQIBfC0DioauOD/yv2
MRPkkmg9eu3kw2Bo0yzEYDDP4KLGE7dQstz+S2buOxPR/Mu71dKf5iXdyPJX3mSE6AmQKQYFZcNt
HYgwA7aTBS75xvZVWKORNQgxnXnaRO1SEbj8aRfukME7ldnmovUHBIRzI5VZyrkA3qVAZ4UJC6lO
S+XqPrmlRNF6wxBWcc7b4ZSyRRVCFVVlfzcu4RnE7//9VQIl/4uxvR0QVcNKaWff2Goe0bSzrQAJ
YiGc6UoQEN1x7nsLZ6uZHTzbITgxi0xnO3zn7azvoanxy5N3OEwoKg9abVZbbmMbDVzAvdQ5hGBC
fadRp8zNnDltm7lE2bi7HF/4M9LXHHHjjfdzzYP7f2QrKWb2v+6/+2mfme6IQqe7BsjiuRDtpuPg
g0NBZcwGdeivOp3AeIK6439NxFxPBpGD8bgZYVkuYHHhaTswQ+X2VdCQzLK3bbSAPJF4g4TlZifX
6avF2pFjYQV+qRSVuCn79nZS0wLTsSi51w6Zq8pr8FV76t2hcar89v7WqmEYKdFM5TLiNcG5LDmQ
Ql292wa2jTTF8oULZPp0qZ8ZCXsRoSFN2tilxQGylzbxFTY6YRtaQDnmZCiwhuEBePTlr7cjCJHO
RRsIP2rNOhy22sbiC1RfulaAWbSKzzLYInL9ir5ep+Lsn36UzVF/GTyK3seIBVx4a0qwCQuvf6qe
TdkFBgm1MfLWL2uu2DZLOvypcQNNFFoIH8D2Up9PWNmtVwZJY5eCeXotXI+R88uXl8+HQpjCPpkn
uoakxyOuwHdUC3LgsgNx+8EP7PNEU+vtbTdbAtd/UV5JxTBKR2z8citnhLOVogFmgWKs2NnuME/t
E8t3MBJ46FvjSGTDNiGB6Ghsvc8Mz0ysa6LQ2OYFoJQwksgKsdJJOUSaRdB68LPDQU2gsT8WU3hW
iM3Kt9vSwJFt8iVvHcjT7rKUkmZKeGd/O4RpS2yid/xqrbxNTOvCMYpiQL0vI1ZKr/fgBSijoNJH
4wmG+VWoMNQfrlsoA9bhlI4EIrvmArOqKQ3370SN8804+hyXW7NVzA/AzEEj+TlIiil1r2SBjYra
XCFajPqqtQDFdMpLmpZdTtPqxcvC3VSiiFQ3iXmwi2mhmp7/iv4PgxQXZLH81khZtM6IbZVQVvcL
YMUBJc5j+6XQUciYJ7olsAegSAwlslxkBnXfNXpQ5q0SFV4d6G4Tc5BNgOaggXTqLUYXN9gRRjUH
Brt4IysngVAhO2Dd/e1ItVBElApRyH6aCZ9gZVWu42FoT31JUjGgAglfJ5tsLDs+u+ppg2O0j1K2
bi2i/gQy70guxeS1J+kXTf3ZJQB53KeI5fGfv7ABtA9OyidVgPihI5NAUVs5SWf6agXiZttrZ/Mr
PE1qJPszMH8iGkSI7+wAFRjCabRNjqfQ/6elswh0va29GrCKbnSzaWDaaL6TKl13KCMwscOKkre3
UF+3aUjzTOP2K7pzLsI+JgAJObAftRy3wWbntJa93BEZYhkv2F0RMEvyU3DuufW1sAHEllOsoAiM
CMu9aXi4GniDXzk8qT/TnwC/u97uuWybMb76sk2hMkM4MCd1q2Jt6wsJAFYmXgm5yThs6Fhygj1K
wMmG5eFZE7YPLsGyCsVM4HluO96zpobKguKN51n4NUqEF/oV08lh0Zk5JhaR/MmEndWTIlJSvNhz
KVx1lt8NRkLDeD/l2PSlV04FTIlYfe5iAtijR+Fs8cK+Q0efywdRtX5qFKEeptjvhG7p66unI1+/
ixvV4X5P0BtTtY8saqU9oTmJcdmpIJbbutzy5AleOfZNsFssrdWfTkfFCiGXqmIlo01gr+Yav+pP
vViXWIGuUksk/OxIUVzWG/atzNHhegYqOL4G97pF+Kgsy7yj/rQ7Boh258Gm5KryhP4K4V3blkOc
dtSnIqhrmb9Dj7MfUXHQ30bRZhqjuWUx0CZc4F00JAjmff4SOpghKqz5MICUb5ToHo9LaBBgtXVK
sZSCXAt841BM0oU4ixusF3NmU3rsivnpFif4dbff7PYk4CKtnNPbG/Lhd4JFqoznlzD0VP2MEj9w
qP5Ow6KOAQGQMdbuoteHiCsct1RQITWPmmBqwOpZidDoX1UvN0otgVQ0IRlDh+XphLwr0idT4sFX
xSKxEndCQNvWH9V+Gso8Tf/R6d85mL3bKvKq+8B7WaN4sKS8T7GDLuskfy14BFE0epAj5wV8Q5oB
pqkKTr4YWrOAo+wk6J/3WKTRNsjPHpFsdPXROmOq3WnKIlgQ/bhTkakLVr8dcVTLrlb8zCE5jINH
2BpuajGw4Kp0WLeP6nRSYQgiOtgCDFPogNVJQBA475qGwRR1TyQe0RCutcNq/QHIldbVYQlBMEPu
97aorjXddyh2WARCwYZrEQefCoBHr0Dn6ldVQ0FliEtkc2JZZvSDqSQ8QDgpL2wHkAhiA85FRpBH
4mZ9fCOKfankLbUlJTqbXknMFemcuJFFSyT6ktyckexpHcH82PtTA13R9jde4O84uqnHxryauSIm
5g61aMarQyZwIjr54ZxuTHDl31X4JPVQgCP63RouIngZdaLkgyU/pIR79xSXpeIArROVCCHHqPfn
bnhzQVUHa7u80Krk4yylNvbLxuJY96PRm5CiBdcs3uV87UO7Ft4Nd7nHdxAiZJEist01LJPQ4Q5X
IvDUuloMQGK0PX+LUO8imlSMeEH+owfbrAzbSWfqMkEHShcaPmmqerBAEjQak8/A3HsZ0qrmJFK/
GxOaX5vv3Pgy928Uk0VsKWEcRrC4PE2rMBlFXYa5ihLF5hfEWmT6EZ+rDVSDaAt261T77yaO/Rmf
gwn8PqkNFLP4AAOB25tjt/K37HyGv4nZdH+22HjZZXnIlc10q4rDn6+8nubjaAzf9hjfcHPy83ty
D8Qc2lbf771Rt58FBnRYx0wGRudqwXqCQq7glxRlEZt0CCLbR21ZQ7e7T8DwmzuTn5ql2pD7HG9J
mAOk3tLP3smvMhUrYf0ZsudBgNOZEYAHR9HGPvzkvMPIOX4q65vSuBaGqfz52Xqorm7q2rBtNoGu
CAbdRLv+xaK9wGAdo/X9RTksutmj5ZXsKZFu4wA+zYqUofc+0eVdhZNn5T9URiB3iNj7c89sUsle
CYJnnJV5gFer26R257abVb9L3tYrUQuz0wdYqiGfo5nHWqgbbfxVe/0PM/gGjrXFG9YjxUVYuUYB
kJFG94WhKm17RcnLc2h+EzwqVjtXGECLNavz4OTopC/Uuvz+3/77+nhmEVTmD7yuNlIecIDu70JY
xXvnNGsdIkMiFDhjORs1pwBoV2BlTScT6faMhTVcbheqjMhT25aJgyVFBZ52p3xiKkphDkqyF5GH
VQ+fdIGdfEE/0f/nuOysb/MhuX/0UclwsDWe+PXu5yvxnsW6HNQg7gPKK78VbyBCbyTz1kA1MMuD
5xb9AcQqRBhicaUn6NdMEiEIqbUXVXAv3TH4SeqIFSg4NihGWTO7mNvUA3hXzCkFAhFX56pigNX6
OGVziyHw8L+qw/FK8yOBYjg8sqzMuum/ZhKp2SJ+i4el8/OG+hvrtfxWRgHGG1u5niSW/izQcVGz
llQ03Zv8QiddTU1Jaa18bDqButirH2Ih8TmFGSfwEa/q1AnGHx2RIDsV7CzH6z7s++aB9shRJB6e
Ofy1Rg2T9oeGyjSWEPCNHFKsjkP3L8RHPp6+ZRxedK/F+8xGcvnjFhOQ9KZfpTCPwt0n92ksg31w
dfLKasJpCKLnuX09pTCjL7wXmPALz5VELRhDjL9bOxdHlWPt/yy8QGtBJlnFHdQlJUm4zEFLCuMd
wtAsDixhG+fWkjCXaEm8RwuoG+K0vvr6RaUqCMNmfYBJ/vKH77glb1vdhLL/E6tzMPY2BkJh0yK9
CRREIpHtFpGoRQ16AiWql/E7ChDO/uS/hkMXJrvvmbMxUtLPl282JAblI/rX7aSNs9HuZeKsKiTJ
uMoh39eSU1j4kjn+l30mhvdcOToljM8I6gf8oLAA3z9uZKX93OmdUgRWGOarWRRYnnmsoN71bmJP
yg8nod4WgIR1zNOxVLLgHuv1yaZNWHeHCni05bIShym8/I22xtkcMN2KYsMavE8VeNOtSKP+B4nk
00zcu9TbT56sk4OU/NiG9yTO0bDff4e8uPkTlhujQ/8Srw1L2ujlpe2WY69HsfTzIrhDvSoKAg0w
GRUrK5VfRxOUX6KqNjklxaAb3KzlvYPCwWbmaQ8PpnvTr1i+zpHqqxLOCiLEEhK3KStT/6PsDlsA
S3R3+oJnti2escUfKkhXr90za9IgMdln3lX+aTFXOkZiC0E2JorG9n6NyHhihwx7Q1dBQCEKFoRp
TCTAsPk0+Fm/9/igqN9TWxTCaT8266V+74sJdUbbOWb1BqhS2ycCIqQF6VoGHS/VPXv+uKRIT6T9
8U9WTDluc3bc2Beh9V9C53wfviCEvER3SD6H+++MQM4m15WWjn4z1ssns1CyECr0pC+1NZtrNBS0
lM6fZGsPObW1Px0BP8KS427XRMhZV3Cly4g4KX8mLS1FsBCZIoosAaBZ5RmkVz5Yul1Kddylyzq3
nLO5pICy1vqHNZWzd74gBUliH4mRlQtMW4+rLc5wBLrnHT1PaB7xRIIJLTGgOsSortggXt6ojQyX
F+9sL3jzQXLAswfuxVhH74N1T1PdguJA1gC+hqUIkJP0TCDj8ptcklEebNsGzmN7f9Q7aolvSsmb
TGhNW8svbhqR1Qj5xeXdoY7m6p5sca77SvQCXvKwHtvhDFLxExLBrJKiCmS6jf/tZWjixU5KE/AC
eWTvYpmlI9hktBJIBbKmRx58q60UyA5enJmbg2+eOXaGCuh1c+hn2G3q45H3CJcNGxfE44QGjmdI
rP8DHJwWnTUGv20fQ9Be5jYbgmGGYOBZmXt45P5fDEBs4FTRkP3UG2gsh7HyxbTLFnawfZEi9HI1
RTs88tcOHe6l+6bb21oLYWYK+s4C6qyFgISaI1OgYUYg+Y5HeW0C5CzHScznYPvhJWf9qzvj9gpj
f1r80t896y1jTpEFCkVfmnKgCsdsuzOTMAOgtFqMNEMdNevo8h/dG8luShUDoafqUm6oIKy0WA/t
FZtjghuID0zjpngbCorsfpdrEOAKRU4I+09+xbRTeJ74S7uvLs049jXzxYk487cW5qkyNstDgvQI
bv+kvtRQYR5IomgtfnUa0xrzPKLil+JgQ32oYH/M4kgWsT5/GLsk+Q81D7fPkK4xCOf3a4EA8PvA
FJ8QX6xpki4xJ0HqQN6PXf98yLzjcAw5fP87Pz8gXTE4RGEmWghwDcMccB+ydhFvkM5UjlPW6Ccy
pDGkB/ZiA9cLoCqudrGj74JNiBlowr9mBtpzXII2UziZWyT4i0aZ8kPMrSWvprjDykZ3e1A5FTxc
+c5DquVsxRkWgtvnGZoQHrUqMVHASsuf2LUrbenQIfJ9E6u7MtWoQaIvHZymBTBqKZzpw7G7GgZO
Jowe9/SFCHTDQwn7Xwsohldl9kod5qknHbdSJSLvhfYr9RtjTknCeW5JtqNkMPG6WKIVthvHBBwr
bIc6mYb3oJy5ER7+851jGYD3S0iR+lngem13gBHUs8PdkfEli3Vh/frdPpaWUGLABYH0Ggq3ffPZ
xvhGmqE8jia/CkC+4tAUkb6wkglJhWybnO0GCh/9e9fVS3RHxntweE4B82liwdufRWeb4ElrkMc9
kVGO1IxqljxEr+UGRcnd+zxi9cIFax1bDP+eciwniZQielqDjjKb3hpDZycn/tc4dh6BsaIzNdst
5LxZEvr2h/aum4WFIh6n2j1AmkIJuXPlU3z1zKKGLp0QR638EXQwwCZunhaIxBXLvmTDAQfB8iHP
S70HPyhlS/KLznYuen6SwSf06PLrWAE3gboZVGWMhuR5LI6xe3L3ozIyLLJHzTEU+Ry/Keq5aZ7o
sgslmYWRMhX9Ho175SQ7wVnAyR7o9vQuRNIGfSdHCmPT70KypS55kpJJR3GmvsP1t34y4WG3oOB6
uwDt1YIlIp1F+P72GdiVq8kgHP58jqOcUdSBgCVbIwEyW3QTrUWOZ5tgooTNFhqs3kjTMLJLjqKM
5ZnLFhzPIF2JmvtXyUDtqvCdkmlYpEiuXxfJY1E02e+EQdvikOnaOAIqrdvcPDiVepSsb27nnu+J
owQs9X5+LzESvnnruRifrE66TN+0CiU864oP6X4z4dOPX2Qky6wU8mmgeEicjJ1x7tXxBcUFktcQ
1bpXvVpeeVmXQGETYpENACuOoemK34Z9EMQ3EbAr4MHA0PJ+nXi9b7P/UZ+FBAqUEHEP2hUoYQKu
OGfsx3UAKG2u6fApeUOPZHoNQWT2OksH4AL+AM8wRGw7nD25qmw/AfB2q4cqdO2QESeY6hkGlrrE
KCebGQeraxwd+s8pN9GJVfARRz/z1W9zPfDuM5CG19utIXJJUYp4JoS7d5Gn/IByI6aI3kBXinyY
Wp6t6DDO+NgbAaPDGlPpFJNFqQP1+roPERwXeV3Wh8oopEjYaq8vPebbL3qISCNIDpGAZnnOZOMN
9HRP7fvDtCyQy7tR1sEgSFHBC5TA56lk8Aw9a9uaq5hz2g7lz4p/GYhvm4E0vE6LBH0BiJcLRdm3
LI9t6TX9ddQdON0VW9i9fT1HUAnFL8kEhbGLLoQ92CWmlZJVDgnkgN0deuYhTf61kHFGVtLMtccm
q4QCgKwAu7zBLLbB3D4UPgNYbua+4tNnHvQ5JAhEWmNOauFgzYBe42wicssMnQ+wfbPhFo3IDiVL
jaHrAWjwDU/K/QD/eP8zZZ3Iau2eoFuVB+Z0+PKpzFjPiAG4T9+bSz0bvy9ny59soY991450tUYz
4RYrCgZSOxh4plDrl8qaWnjK1ds4Te81oog6GMAOzAOChyFqtpRtC4ywbmUdzGp0dZT6rDh8BaU1
HUIagqHwT1SH8TvdCOwG3oC4aXi42+5Pu0GYxuRprGxlg5XcW8UhjgHnVV3gPS1UfE9PKOhl8T2a
hTAd3T7DM9vc3Y+ZTPsePXYjRnEBJUO9el4xczz92f8A7puEsGASA11NTcA0+84HPnlOeP4iwpze
XJpH3zCqFGpy8eb71gnz44bdiJ+pguplIXV4si8tj2s3Y80LIrJlfBp1I8QceUavjrVcVqFOKHiU
s2ZC3lcAVBbSMYqcmavxrd7n/UesSBc4zolQENclyQWvyKmRDV2jrZo7oZtlJOC2EAwBIQ0N30bz
7UOPv7Th7NvczdcKQdhfASiVfsi+6oBINGsT21KbiP/0WwKtnA8UBBXTe7COCS9WXvc8bFsrpme8
lRHsVjWsXYBOWYNFOS9hGEAbuh9gyyMFeB0sKnKl6ApnJP/l3nQf401LpSzFdEcFgD0zX8gmyYhq
feyZOsBUPr6D7E0LNMNohLS5vO+3GQNJ5MazCPZO45OvGI1CRaD9jYqnZzydjaiEey4RDGcms6Cd
6PFIPNd2BCiXgPwWmillcMvr++GMs5mXDNGzVsVUSwzcsZK1xJkMx92sh0aPedEZBJsnpXQmLAUU
Hhl9iGLFU/8XkdNyjcVdG5z22dUsyVGuY4aBbbM1VeU0Bm89lvPajfkakItcfrVjjhRC/jtWMAfo
AhwT8J6aSqZWsHkIRj1NkR1l8RPac+kd0AU61gPJYi3IHr+T9sy5FZByjIHWYi8KbHNAxPjipP4s
z75QeOoxw6Xk/BulW+U/ule+Zl0sFiYi0677N1LQ9rVTuJsonksl8anU2qC0Pn42UYohjzrchUtt
jfr+LDMx55lWN2jMkgSBPZhD54G2OiSAQU2858K48eI9e1KS28nMTXKKflFym/iZ7OSdtGND39zv
8PX5n/x+kGNqQ8IExFCZbJ1BXWK2oEEtqHp/9oBSwpPMKhgyhiWyBy0+rC13Nulm0HuOV3fWv2Ww
JRB3hY6eT9fuC0LpoGPqppPYMwKBq43oVEkynu0/mk69rVmBYwHkS5/xrv2b8xoAsGFDblg1xni9
SsZXkFznh/fxKqVa+PD6eqxa/HMx9g/wjk5yP7DgBoXFzrnmuUeHuAzyB5hZNW6h9JsoPv1lGY4P
Z4HSBHagMg60N/zv3wGfsyva+lk33hvwiM7ouq0dTJMUGQ6/Tdajr51zBNu2csmzYK1x8TC5z0qL
jfJ4+wSdytPqJaF0LO7mLbnLbXUecBknzqYDqWXCqlK8dFoOhfT34KvsCsR9v9VFPJ0y+/6/MYAJ
tNfPpA1swyTDnj56SufmjfBGOlwbmw8Qdra6ybz3mKTQ6r9t/yQa/fEGviHc6AzdnsN595YVQ3Y/
D2QAnIHdXNee9VTJQJab+3JQK2uEKBnGwDYn1qyVEtzIheXopzsImxd9GlxyQOWGnfAVS672XK0x
UXOpRj8vY+ADHbHmd4YvzwjdVTlOsqwylQHAm2QarDxLUhaIY17y77SpVnJntxxuOHW9SZDEKayw
/U0VUx4J6qDTzIfQksCUC9Q8zrVsv6TsjZntzEowYoNIQntipsvFSa48a2qpHLa8FKvSjnSzhVfW
eW9AFE8tohI8TEmFkXKLrUgOldrUWdFuQXXQcp6XeYDYSfJI6OtEkw6e4VVDeJKlySyobzDdz/7S
4CR5NO9YdpkIDtZvxloJUEblFgZTRFdobla/g+SONw6ISImuaIwJjkWXuLNJvsErgXw8vyPx83UC
FxcMTm5ETz3b60xwIRHA4kK584JNeIup8jL06aUdFTiZleOjI8HPR/KAj1n0TFQlxwl0LdiGv+Wo
u2ngA2cxoRem+e5L6pe35B9vpuV4osJTTeUl9c68xT99G7TLNHciKMwp/nCUhoem+CUo/O6P+MN6
YoeIwJsTL/I1El6wl60Qp0ygp5LjaDj9F0HqgWGzliH9QAO+SqYxWUbvvej2cfIb/aECNXzPzp9/
vG7SPS/cUXm8+NsXfH4AAzMGAdF6TqaxihvlTmFepIPEfU0+AWmIfMGID5QZtlQRHJwbUr5pUxza
6GnI3fCbTUCElGpHOSnElPs0rFiw5Ye3n05H+FeIEAwuPJbJVzWOkfYlnyKRavQnS+GqWBkeAShQ
Tu/2V8/DwaHfqKjpxN59c9ATquEzb/kO5BG5Biq1PPaftmuJ5SACCx+YEmI55lehqWe2jJmKP9YA
RRFFfvQpF9GqX9m/sk674EX/JIuh2ZsnYnAwdvmVyKMZ7sYfrm1W2kfdJScfV1AwYj6lLVwX09Sd
HJHX4KIQqRwEDm1WmfARy3PnunuDwsgdmWA6nA==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
